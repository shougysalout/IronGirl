<div class="vt_results">
	<div class="opt">
		<label for="op1">ممتاز <span>- عدد الاصوات 358</span></label>
		<div class="chart" data-title="60"></div>
	</div>

	<div class="opt">
		<label for="op2">جيد <span>- عدد الاصوات 108</span></label>
		<div class="chart" data-title="25"></div>
	</div>

	<div class="opt">
		<label for="op3">مقبول <span>- عدد الاصوات 41</span></label>
		<div class="chart" data-title="15"></div>
	</div>
</div>