<!DOCTYPE html>

<html lang="en">
<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimal-ui ,user-scalable=no" name="viewport">
    <meta content="" name="description">
    <meta content="" name="keywords">
    <meta content="structure/static/def_fb_img.png" property="og:image" >

    <title>مدونة تـويوتا :: المقالات - نادي تويوتا - الصور - الفيديو - المسابقات والفعاليات</title>
    <!-- Media -->
    <link href="favicon.ico" rel="shortcut icon" type="image/x-icon">

    <!-- Stylesheet -->
    <link href="css/normalize.css" rel="stylesheet">
    <link href="css/layout.css" rel="stylesheet">

    <!-- Javascript -->
    <script src="js/jquery-2.1.4.min.js"></script>
    <script src="js/jquery.easing.1.3.js"></script>
    <script src="js/jquery.functions.js"></script>

    <!-- Assist -->
    <script src="js/jquery.transit.min.js"></script>
    <script src="js/jquery.fitvids.js"></script>

    <!--[if gte IE 9]>
		<link href="css/ie.css" rel="stylesheet">
	<![endif]-->
</head>

<body>
    <div class="loader" id="loader">
        <div class="set_tabel">
            <div class="set_cell">
                <div class="logo_load"><img alt="" src="structure/static/t_logo.png"></div>
            </div>
        </div>
    </div>

    <div class="side_menu_set">
        <div class="nav_set">
            <div class="nav">
                <a href="/">المقالات</a>
                <a href="/">نادي تويوتا</a>
                <a href="/">افكاركم</a>
                <a href="/">الصور</a>
                <a href="/">الفيديو</a>
                <a href="/">المسابقات والفعاليات</a>
            </div>
        </div>
    </div>

    <header>
        <div class="header_set">
	        <div class="gb">
	            <div class="logo_set">
	                <a class="logo_ic" href="/">
	                <div class="logo"><img alt="" src="structure/static/t_logo.png"></div></a>

	                <div class="logo_tp no-select">مدونة تويوتا</div>
	            </div>

	            <div class="menu_icon">
	                <i></i>
	                <i></i>
	                <i></i>
	            </div>

				<div class="navigation">
					<a class="nav_icon search" href="javascript:void(0)" data-id="search">
						<div class="inner_icn">
							<i></i>
							<i></i>
						</div>
					</a>
					<a class="nav_icon login" href="javascript:void(0)" data-id="login">
						<div class="inner_icn">
							<i></i>
							<i></i>
						</div>
					</a>
				</div>

                <nav dir="rtl">
                    <a href="/" data-id="articles">المقالات</a>
                    <a href="/" data-id="toyotaclup">نادي تويوتا</a>
                    <a href="/" data-id="images">الصور</a>
                    <a href="/" data-id="videos">الفيديو</a>
                    <a href="/" data-id="events">المسابقات والفعاليات</a>
                </nav>

	            <div class="clrfix"></div>
        	</div>
        </div>

        <div class="sub_menu">
        	<div class="sm_set">
        		<div class="gb">
        			<div class="sm_wrapper" id="search">
        				<form action="#">
        					<div class="sr_input hide">
        						<input type="text" placeholder="كلمات البحث">
                                <a href="javascript:void(0)" class="sr_submit" id="searchSubmit"></a>
        					</div>
        				</form>
        			</div>
        			<div class="sm_wrapper" id="login">
                        <a href="javascript:void(0)" class="btn hide gray">تسجيل</a>
                        <a href="javascript:void(0)" class="btn hide red">دخول</a>
                    </div>

        			<div class="sm_wrapper" id="articles">
        				<h3 class="hide">المقالات</h3>
        				<div class="sm_grid">
        					<div class="sm_block">
        						<span class="hide">تجريبي السيدان</span>
        						<a class="hide" href="/">تويوتا 86</a>
        						<a class="hide" href="/">كورولا</a>
        						<a class="hide" href="/">يارس</a>
        						<a class="hide" href="/">افالون</a>
        						<a class="hide" href="/">اوريون</a>
        						<a class="hide" href="/">كامري</a>
							</div>

        					<div class="sm_block">
        						<span class="hide">تجريبي دفع رباعي</span>
        						<a class="hide" href="/">سيكويا</a>
        						<a class="hide" href="/">لاند كروزر</a>
        						<a class="hide" href="/">برادو</a>
        						<a class="hide" href="/">اف جيه كروزر</a>
        						<a class="hide" href="/">فوتشنر</a>
        						<a class="hide" href="/">راف فور</a>
        						<a class="hide" href="/">بريفيا</a>
        						<a class="hide" href="/">إنوفا</a>
							</div>

        					<div class="sm_block">
        						<span class="hide">تجريبي تجارية</span>
        						<a class="hide" href="/">لاند كروزر 70</a>
        						<a class="hide" href="/">هايلكس</a>
        						<a class="hide" href="/">هاي إس</a>
        						<a class="hide" href="/">كوستر</a>
        						<a class="hide" href="/">دينا</a>
							</div>

        					<div class="sm_block">
        						<span class="hide">مواضع عامة</span>
        						<a class="hide" href="/">محركات تويوتا</a>
        						<a class="hide" href="/">انظمة السلامة</a>
        						<a class="hide" href="/">تجريبي مستقبلية</a>
        						<a class="hide" href="/">سباقات تويوتا</a>
        						<a class="hide" href="/">اخبار تويوتا</a>
							</div>

        					<div class="sm_block">
        						<span class="hide">التطوير</span>
        						<a class="hide" href="/">التصميم</a>
							</div>
        				</div>
            			<div class="clrfix"></div>
        			</div>

        			<div class="sm_wrapper" id="toyotaclup">
        				<h3 class="hide">نادي تويوتا</h3>
        				<div class="sm_grid">
        					<div class="sm_block">
        						<span class="hide">قائمة تجريبية</span>
        						<a class="hide" href="/">رابط تجريبي</a>
        						<a class="hide" href="/">رابط تجريبي</a>
        						<a class="hide" href="/">رابط تجريبي</a>
        						<a class="hide" href="/">رابط تجريبي</a>
        						<a class="hide" href="/">رابط تجريبي</a>
							</div>
        				</div>
        				<div class="sm_grid">
        					<div class="sm_block">
        						<span class="hide">قائمة تجريبية</span>
        						<a class="hide" href="/">رابط تجريبي</a>
        						<a class="hide" href="/">رابط تجريبي</a>
        						<a class="hide" href="/">رابط تجريبي</a>
        						<a class="hide" href="/">رابط تجريبي</a>
							</div>
        				</div>
            			<div class="clrfix"></div>
        			</div>
        		</div>
        	</div>
        </div>
    </header>

    <div class="content st">
        <div class="gb">
            <div class="section bx_fx bx_unq">
                <div class="box box_tb">
                    <div class="ov_cap_set">
                        <div class="ov_date">
                            <strong>22</strong>
                            <span>مايو</span>
                            <div class="ov_bg"></div>
                        </div>

                        <div class="ov_title">
                            <div class="set_tabel">
                                <div class="set_cell" dir="rtl">كامري 2016 ترتقي بمعايير فئة السيدان</div>
                            </div>

                            <div class="ov_bg"></div>
                        </div>
                    </div>

                    <div class="bimg_set">
                        <div class="bimg has_img"><img alt="" data-id="structure/assist/1.jpg" src="non"></div>
                    </div>
                </div>

                <div class="box box_tb">
                    <div class="ov_cap_set">
                        <div class="ov_date">
                            <strong>22</strong>
                            <span>مايو</span>
                            <div class="ov_bg"></div>
                        </div>

                        <div class="ov_title">
                            <div class="set_tabel">
                                <div class="set_cell" dir="rtl">كامري 2016 ترتقي بمعايير فئة السيدان</div>
                            </div>

                            <div class="ov_bg"></div>
                        </div>
                    </div>

                    <div class="bimg_set">
                        <div class="bimg has_img"><img alt="" data-id="structure/assist/2.jpg" src="non"></div>
                    </div>
                </div>

                <div class="box">
                    <div class="ov_cap_set">
                        <div class="ov_date">
                            <strong>22</strong>
                            <span>مايو</span>
                            <div class="ov_bg"></div>
                        </div>

                        <div class="ov_title">
                            <div class="set_tabel">
                                <div class="set_cell" dir="rtl">كامري 2016 ترتقي بمعايير فئة السيدان</div>
                            </div>

                            <div class="ov_bg"></div>
                        </div>
                    </div>

                    <div class="bimg_set">
                        <div class="bimg has_img"><img alt="" data-id="structure/assist/3.jpg" src="non"></div>
                    </div>
                </div>

                <div class="box">
                    <div class="ov_cap_set">
                        <div class="ov_date">
                            <strong>22</strong>
                            <span>مايو</span>
                            <div class="ov_bg"></div>
                        </div>

                        <div class="ov_title">
                            <div class="set_tabel">
                                <div class="set_cell" dir="rtl">كامري 2016 ترتقي بمعايير فئة السيدان</div>
                            </div>

                            <div class="ov_bg"></div>
                        </div>
                    </div>

                    <div class="bimg_set">
                        <div class="bimg has_img"><img alt="" data-id="structure/assist/4.jpg" src="non"></div>
                    </div>
                </div>
            </div>

            <aside>
                <div class="box">
                    <div class="as_cap_set">
                        <div class="as_cap">
                            <div class="asc_border"></div>

                            <div class="asc_arrow"></div>

                            <div class="asc_title">
                                <div class="set_tabel">
                                    <div class="set_cell" dir="rtl">تويوتا تطلق نسختها السباقية من راف 4</div>
                                </div>
                            </div>

                            <div class="asc_date_set">
                                <div class="asc_date" dir="rtl">22 يوليو</div>

                                <div class="asc_line"></div>
                            </div>
                        </div>
                    </div>

                    <div class="in_slides">
                        <div class="in_slide active">
                            <div class="has_img"><img alt="" data-id="structure/assist/5.jpg" src="non"></div>
                        </div>
                        <div class="in_slide">
                            <div class="has_img"><img alt="" data-id="structure/assist/6.jpg" src="non"></div>
                        </div>
                        <div class="in_slide">
                            <div class="has_img"><img alt="" data-id="structure/assist/7.jpg" src="non"></div>
                        </div>
                    </div>
                </div>

                <div class="box">
                    <div class="as_cap_set">
                        <div class="as_cap">
                            <div class="asc_border"></div>

                            <div class="asc_arrow"></div>

                            <div class="asc_title">
                                <div class="set_tabel">
                                    <div class="set_cell" dir="rtl">تويوتا تطلق نسختها السباقية من راف 4</div>
                                </div>
                            </div>

                            <div class="asc_date_set">
                                <div class="asc_date" dir="rtl">22 يوليو</div>

                                <div class="asc_line"></div>
                            </div>
                        </div>
                    </div>

                    <div class="in_slides">
                        <div class="in_slide active">
                            <div class="has_img"><img alt="" data-id="structure/assist/6.jpg" src="non"></div>
                        </div>
                        <div class="in_slide">
                            <div class="has_img"><img alt="" data-id="structure/assist/5.jpg" src="non"></div>
                        </div>
                        <div class="in_slide">
                            <div class="has_img"><img alt="" data-id="structure/assist/7.jpg" src="non"></div>
                        </div>
                    </div>
                </div>

                <div class="box">
                    <div class="as_cap_set">
                        <div class="as_cap">
                            <div class="asc_border"></div>

                            <div class="asc_arrow"></div>

                            <div class="asc_title">
                                <div class="set_tabel">
                                    <div class="set_cell" dir="rtl">تويوتا تطلق نسختها السباقية من راف 4</div>
                                </div>
                            </div>

                            <div class="asc_date_set">
                                <div class="asc_date" dir="rtl">22 يوليو</div>

                                <div class="asc_line"></div>
                            </div>
                        </div>
                    </div>

                    <div class="in_slides">
                        <div class="in_slide active">
                            <div class="has_img"><img alt="" data-id="structure/assist/7.jpg" src="non"></div>
                        </div>
                        <div class="in_slide">
                            <div class="has_img"><img alt="" data-id="structure/assist/6.jpg" src="non"></div>
                        </div>
                        <div class="in_slide">
                            <div class="has_img"><img alt="" data-id="structure/assist/5.jpg" src="non"></div>
                        </div>
                    </div>
                </div>
            </aside>

            <div class="clrfix"></div>
        </div>
    </div>

    <div class="content nd">
        <div class="gb">
            <div class="section bx_fx">
                <div class="top_line ln_black"></div>

                <div class="ut_title">المواضيع الأكثر مشاهدة</div>

                <div class="boxes">
                    <div class="box box_tb">
                        <div class="nd_img">
                            <div class="nd_link">
                                <div class="nd_link_icon">
                                	<i></i>
                                </div>
                            </div>

                            <div class="has_img"><img alt="" data-id="structure/assist/8.jpg" src="non"></div>
                        </div>

                        <div class="nd_cap_set">
                            <div class="ndc_date" dir="rtl">22 يوليو</div>

                            <div class="ndc_text">
                                <div class="ndc_title" dir="rtl">تعرف معنا على محرك تويوتا الجديد</div>

                                <div class="ndc_info" dir="rtl">قد يتساءل الكثيرون عن ماهية نظام «VVT-i» الذي تستخدمه شركة تويوتا في العديد من محركاتها الجديدة، وهل يختلف هذا النظام عن بعض الأنظمة المماثلة في محركات تجريبي ...</div>
                            </div>
                        </div>
                    </div>

                    <div class="box box_tb">
                        <div class="nd_img">
                            <div class="nd_link">
                                <div class="nd_link_icon">
                                	<i></i>
                                </div>
                            </div>

                            <div class="has_img"><img alt="" data-id="structure/assist/9.jpg" src="non"></div>
                        </div>

                        <div class="nd_cap_set">
                            <div class="ndc_date" dir="rtl">22 يوليو</div>

                            <div class="ndc_text">
                                <div class="ndc_title" dir="rtl">تعرف معنا على محرك تويوتا الجديد</div>

                                <div class="ndc_info" dir="rtl">قد يتساءل الكثيرون عن ماهية نظام «VVT-i» الذي تستخدمه شركة تويوتا في العديد من محركاتها الجديدة، وهل يختلف هذا النظام عن بعض الأنظمة المماثلة في محركات تجريبي ...</div>
                            </div>
                        </div>
                    </div>

                    <div class="box">
                        <div class="nd_img">
                            <div class="nd_link">
                                <div class="nd_link_icon">
                                	<i></i>
                                </div>
                            </div>

                            <div class="has_img"><img alt="" data-id="structure/assist/10.jpg" src="non"></div>
                        </div>

                        <div class="nd_cap_set">
                            <div class="ndc_date" dir="rtl">22 يوليو</div>

                            <div class="ndc_text">
                                <div class="ndc_title" dir="rtl">تعرف معنا على محرك تويوتا الجديد</div>

                                <div class="ndc_info" dir="rtl">قد يتساءل الكثيرون عن ماهية نظام «VVT-i» الذي تستخدمه شركة تويوتا في العديد من محركاتها الجديدة، وهل يختلف هذا النظام عن بعض الأنظمة المماثلة في محركات تجريبي ...</div>
                            </div>
                        </div>
                    </div>

                    <div class="box">
                        <div class="nd_img">
                            <div class="nd_link">
                                <div class="nd_link_icon">
                                	<i></i>
                                </div>
                            </div>

                            <div class="has_img"><img alt="" data-id="structure/assist/11.jpg" src="non"></div>
                        </div>

                        <div class="nd_cap_set">
                            <div class="ndc_date" dir="rtl">22 يوليو</div>

                            <div class="ndc_text">
                                <div class="ndc_title" dir="rtl">تعرف معنا على محرك تويوتا الجديد</div>

                                <div class="ndc_info" dir="rtl">قد يتساءل الكثيرون عن ماهية نظام «VVT-i» الذي تستخدمه شركة تويوتا في العديد من محركاتها الجديدة، وهل يختلف هذا النظام عن بعض الأنظمة المماثلة في محركات تجريبي ...</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <aside>
                <div class="top_line ln_red"></div>

                <div class="ut_title fk no-select">
                    -
                </div>

                <div class="boxes">
                    <div class="box_adds">
                        <div class="ads_slider">
                            <div class="slides">
                                <div class="slide has_img"><img alt="" data-id="structure/assist/add_1.jpg" src="non"></div>
                                <div class="slide has_img"><img alt="" data-id="structure/assist/add_1.jpg" src="non"></div>
                                <div class="slide has_img"><img alt="" data-id="structure/assist/add_1.jpg" src="non"></div>
                                <div class="slide has_img"><img alt="" data-id="structure/assist/add_1.jpg" src="non"></div>
                            </div>
                        </div>
                    </div>

                    <div class="ttl">معرض الصور</div>

                    <div class="box_gallery">
                        <div class="bxg_img">
                            <div class="has_img"><img alt="" data-id="structure/gallery/thumbs/1.jpg" src="non"></div>
                        </div>

                        <div class="bxg_img">
                            <div class="has_img"><img alt="" data-id="structure/gallery/thumbs/2.jpg" src="non"></div>
                        </div>

                        <div class="bxg_img">
                            <div class="has_img"><img alt="" data-id="structure/gallery/thumbs/3.jpg" src="non"></div>
                        </div>

                        <div class="bxg_img">
                            <div class="has_img"><img alt="" data-id="structure/gallery/thumbs/4.jpg" src="non"></div>
                        </div>

                        <div class="bxg_img">
                            <div class="has_img"><img alt="" data-id="structure/gallery/thumbs/5.jpg" src="non"></div>
                        </div>

                        <div class="bxg_img">
                            <div class="has_img"><img alt="" data-id="structure/gallery/thumbs/6.jpg" src="non"></div>
                        </div>
                    </div>
                </div>
            </aside>

            <div class="clrfix"></div>
        </div>
    </div>

    <div class="content rd">
        <div class="gb">
            <div class="section">
                <div class="top_line ln_black"></div>

                <div class="ut_title">الفيديو</div>

                <div class="video_box">
                    <div class="video_set"><iframe width="724" height="407" src="https://www.youtube.com/embed/0N_pderSBpM?rel=0&amp;controls=0&amp;showinfo=0" frameborder="0" allowfullscreen></iframe></div>
                </div>

                <div class="wide_add"><img alt="" src="structure/assist/add_2.jpg"></div>
            </div>

            <aside>
                <div class="top_line ln_red"></div>

                <div class="ut_title">التصويت</div>

                <div class="vote_box ast_box">
                    <div class="vt_title">ما رايك بالتصميم الجديد لمدونة تويوتا ؟</div>

                    <div class="vt_options">
                        <div class="vt_load" dir="rtl">
                            <div class="set_tabel">
                                <div class="set_cell">برجاء الانتظار..</div>
                            </div>
                        </div>

                        <div id="get_res">
                            <form action="#" class="in_action">
                                <div class="opt">
                                    <label for="op1">ممتاز</label>
                                    <input id="op1" name="option" type="radio" value="ممتاز">
                                </div>

                                <div class="opt">
                                    <label for="op2">جيد</label>
                                    <input id="op2" name="option" type="radio" value="جيد">
                                </div>

                                <div class="opt">
                                    <label for="op3">مقبول</label>
                                    <input id="op3" name="option" type="radio" value="مقبول">
                                </div>
                            </form>
                        </div>
                    </div>

                    <div class="vt_action">
                        <a href="javascript:void(0)">تصويت</a>
                    </div>
                </div>

                <a class="post_box ast_box" href="javascript:void(0)">
	                <div class="post_box_hover"></div>

	                <div class="ps_title"><img alt="" src="structure/static/post.png"></div>

	                <div class="ps_spr"></div>

	                <div class="ps_action">
	                    <span>اكتب مقالك الآن</span>

	                    <div class="ps_arrows">
	                        <i></i>
	                        <i></i>
	                    </div>
	                </div>
				</a>
            </aside>

            <div class="clrfix"></div>
        </div>
    </div>

    <footer>
        <div class="ft_top">
            <div class="gb">
                <div class="ft_grid">
                    <div class="ft_row">
                        <div class="r_head">
                            <i></i>
                            <span>الاقسام</span>
                        </div>

                        <div class="r_links">
                            <a href="/"><span>المقالات</span></a>
                            <a href="/"><span>نادي تويوتا</span></a>
                            <a href="/"><span>افكاركم</span></a>
                            <a href="/"><span>الصور</span></a>
                            <a href="/"><span>الفيديو</span></a>
                            <a href="/"><span>المسابقات والفعاليات</span></a>
                        </div>
                    </div>

                    <div class="ft_row">
                        <div class="r_head">
                            <i></i>
                            <span>تويوتا</span>
                        </div>

                        <div class="r_links">
                            <a href="/"><span>الرئيسية</span></a>
                            <a href="/"><span>تويوتا السعودية</span></a>
                            <a href="/"><span>سياسة الخصوصية</span></a>
                            <a href="/"><span>شروط الإستخدام</span></a>
                            <a href="/"><span>أخبر صديقك</span></a>
                            <a href="/"><span>اتصل بنا</span></a>
                        </div>
                    </div>

                    <div class="ft_row lst_row">
                        <div class="r_email_set">
                            <div class="re_title">اشترك بالقائمة البريدية</div>

                            <div class="re_form">
                                <form action="#">
                                    <div class="re_input_set">
                                        <div class="re_input">
                                            <input id="email" name="email" type="text">

                                            <div class="placeholder">بريدك الالكتروني</div>
                                        </div>

                                        <div class="re_submit">
                                            <i></i> <input type="submit" value="">
                                        </div>

                                        <div class="clrfix"></div>
                                    </div>
                                </form>
                            </div>

                            <div class="clrfix"></div>
                        </div>

                        <div class="r_social_set">
                            <div class="rs_icons">
                                <a class="fb" href="/">
	                                <div class="icn_an">
	                                    <i></i>
	                                    <i></i>
	                                </div>
                                </a>
                                <a class="tw" href="/">
	                                <div class="icn_an">
	                                    <i></i>
	                                    <i></i>
	                                </div>
                                </a>
                                <a class="yt" href="/">
	                                <div class="icn_an">
	                                    <i></i>
	                                    <i></i>
	                                </div>
                                </a>
                                <a class="in" href="/">
	                                <div class="icn_an">
	                                    <i></i>
	                                    <i></i>
	                                </div>
                                </a>
                            </div>

                            <div class="rs_title">تابعنا على</div>
                        </div>
                    </div>

                    <div class="clrfix"></div>
                </div>
            </div>
        </div>

        <div class="ft_btm">
            <div class="gb">
                <div class="ftb_title">مدونة تويوتا</div>

                <div class="ftb_rights"><img alt="عبداللطيف جميل" src="structure/static/logo_footer.png"></div>

                <div class="clrfix"></div>
            </div>
        </div>
    </footer>
</body>
</html>