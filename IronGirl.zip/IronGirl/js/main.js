﻿
jQuery(document).ready(function() {

    jQuery(document).on('focusin','#search-txt',function() {
        jQuery('#btn-search').css({"background-color": "#fff"});
    });
	jQuery(document).on('focusout','#search-txt',function() {
        jQuery('#btn-search').css({"background-color": "#1a1e21"});
    });

    jQuery(document).click(function() {
        jQuery('#dropdown-menu').slideUp(100);
        jQuery("#dropdown-notification-click").removeClass('dropdown-notification-click-open');
    });

    jQuery(document).on('click', '#dropdown-menu>ul>li>a', function() {
        return true;
    });
	
	jQuery(document).on('click', '.on-off-status-event', function () {
        if (jQuery(this).hasClass('on-off-status-off')) {
            jQuery('.btn-upload-img-progress-view').show(0);
            jQuery('.lbl-txtinput-ads').text('رابط الاعلان');
        }
        else {
            jQuery('.btn-upload-img-progress-view').hide(0);
            jQuery('.lbl-txtinput-ads').text('رابط الفعالية');
        }
    });

    /*jQuery(document).on('mouseover','#main-menu>ul>li>a',function() {
        jQuery(this).find('span').addClass('main-menu-span-hover');
        jQuery(this).find('i').addClass('main-menu-i-hover');
        jQuery(this).parent().addClass('main-menu-li-hover');
        jQuery(this).parent().find('.arrow-right-li').show();
    });
	jQuery(document).on('mouseleave','#main-menu>ul>li>a',function() {
        if (!jQuery(this).hasClass('main-menu-a-select-page')) {
            jQuery(this).find('span').removeClass('main-menu-span-hover');
            jQuery(this).find('i').removeClass('main-menu-i-hover');
            jQuery(this).parent().removeClass('main-menu-li-hover');
            jQuery(this).parent().find('.arrow-right-li').hide();
        }
    });*/

    jQuery(document).on('click','#main-menu>ul>li>a',function() {
        jQuery('#main-menu>ul>li>a').removeClass('main-menu-a-select-page');
        jQuery('#main-menu>ul>li>a').find('span').removeClass('main-menu-span-hover');
        jQuery('#main-menu>ul>li>a').find('i').removeClass('main-menu-i-hover');
        jQuery('#main-menu>ul>li>a').parent().removeClass('main-menu-li-hover');
        jQuery('#main-menu>ul>li>a').parent().find('.arrow-right-li').hide();

        jQuery(this).addClass('main-menu-a-select-page');

        if (jQuery(this).hasClass('main-menu-a-select-page')) {
            jQuery(this).find('span').addClass('main-menu-span-hover');
            jQuery(this).find('i').addClass('main-menu-i-hover');
            jQuery(this).parent().addClass('main-menu-li-hover');
            jQuery(this).parent().find('.arrow-right-li').show();
        }
		jQuery(document).click();
    });

    //jQuery('#controlpanel-home').click();

    jQuery('#controlpanel-menu-images').click();

    jQuery(document).on('click', '.open-close-main-menu', function () {
        if ((jQuery('#rightpanel').css('width') == '260px') && (window.innerWidth > 880)) {
            jQuery('#main-menu a').css({ 'width': '65px' });
            jQuery('#main-menu a span').css({ 'width': '0px', 'padding': '0px', 'display':'none' });
            jQuery('#rightpanel').animate({ width: "64px" }, 100);
            jQuery('#rightpanel-gray').animate({ width: "65px" }, 100);
            jQuery(this).removeAttr('id').attr('id', 'close-main-menu');
            if(jQuery('body').attr('lang')=='ar')
            {
                jQuery('#leftpanel').animate({ marginRight: "65px" }, 100);
            }
            else
            {
                jQuery('#leftpanel').animate({ marginLeft: "65px" }, 100);   
            }
        }
        else if ((jQuery('#rightpanel').css('width') == '64px') && (window.innerWidth > 880)) {
            jQuery('#rightpanel').animate({ width: "260px" }, 200);
            jQuery('#rightpanel-gray').animate({ width: "260px" }, 200);
            jQuery('#main-menu a').css({ 'width': '100%' });
            jQuery(this).removeAttr('id');
            jQuery(this).removeAttr('id').attr('id', 'open-main-menu');
            if(jQuery('body').attr('lang')=='ar')
            {
                jQuery('#leftpanel').animate({ marginRight: "261px" }, 200);
                jQuery('#main-menu a span').css({ 'width': '100px', 'padding-right': '20px', 'padding-top': '25px', 'display':'block' });
            }
            else
            {
                jQuery('#leftpanel').animate({ marginLeft: "261px" }, 200);
                jQuery('#main-menu a span').css({ 'width': '100px', 'padding-left': '20px', 'padding-top': '25px', 'display':'block' });
            }
        }
        else if ((jQuery('#rightpanel').css('width') == '200px') && (window.innerWidth <= 880)) {
            jQuery('#main-menu a').css({ 'width': '65px' });
            jQuery('#main-menu a span').css({ 'width': '0px', 'padding': '0px', 'display':'none' });
            jQuery('#rightpanel').animate({ width: "64px" }, 100);
            jQuery('#rightpanel-gray').animate({ width: "65px" }, 100);
            jQuery(this).removeAttr('id').attr('id', 'close-main-menu');
            if(jQuery('body').attr('lang')=='ar')
            {
                jQuery('#leftpanel').animate({ marginRight: "65px" }, 100);
            }
            else
            {
                jQuery('#leftpanel').animate({ marginLeft: "65px" }, 100);   
            }
        }
        else if ((jQuery('#rightpanel').css('width') == '64px') && (window.innerWidth <= 880)) {
            jQuery('#rightpanel').animate({ width: "200px" }, 200);
            jQuery('#rightpanel-gray').animate({ width: "200px" }, 200);
            jQuery('#main-menu a').css({ 'width': '100%' });
            jQuery(this).removeAttr('id');
            jQuery(this).removeAttr('id').attr('id', 'open-main-menu');
            if(jQuery('body').attr('lang')=='ar')
            {
                jQuery('#leftpanel').animate({ marginRight: "261px" }, 200);
                jQuery('#main-menu a span').css({ 'width': '100px', 'padding-right': '20px', 'padding-top': '25px', 'display':'block' });
            }
            else
            {
                jQuery('#leftpanel').animate({ marginLeft: "261px" }, 200);
                jQuery('#main-menu a span').css({ 'width': '100px', 'padding-left': '20px', 'padding-top': '25px', 'display':'block' });
            }
        }
        return false;
    });
    
    jQuery(document).on('click',"#leftpanel-menu>ul>li>a",function() {
        jQuery("#leftpanel-menu>ul>li>a").removeClass("leftpanel-menu-active");
        jQuery(this).addClass("leftpanel-menu-active");
    })

    jQuery(document).on('mouseover','.statistics-num-region',function() {
        jQuery(this).addClass('statistics-num-region-hover');
        jQuery(this).find('.statistics-num-name').addClass('statistics-num-name-hover');
    });
	jQuery(document).on('mouseleave','.statistics-num-region',function() {
        jQuery(this).removeClass('statistics-num-region-hover');
        jQuery(this).find('.statistics-num-name').removeClass('statistics-num-name-hover');
    });

    $(document).on('click',"#recent-tabs>ul>li>a",function() {
        $("#recent-tabs>ul>li>a").removeAttr("class");
        $(this).addClass("recent-tabs-active");
        if ($('#articles-click').hasClass("recent-tabs-active")) {
            $("#articles-tab").show();
            $("#comments-tab").hide();
            $("#media-tab").hide();
        }
        if ($('#comments-click').hasClass("recent-tabs-active")) {
            $("#articles-tab").hide();
            $("#media-tab").hide();
            $("#comments-tab").show();
        }
        if ($('#media-click').hasClass("recent-tabs-active")) {
            $("#articles-tab").hide();
            $("#comments-tab").hide();
            $("#media-tab").show();
        }
        return false;
    });

    jQuery(document).click(function() {
        jQuery('.application-menu-dropdown-list').css({'display':'none'});
        jQuery('.application-menu-dropdown').parent().removeClass('application-menu-dropdown-region-open');
        //jQuery('.application-menu-dropdown').css({'background-position': '14px top', 'border-bottom-right-radius': '20px', 'border-bottom-left-radius': '20px'});
    });

    jQuery(document).on('click','.application-menu-dropdown',function(e) {

        if (!jQuery(this).parent().find('.application-menu-dropdown-list').is(':visible')) {
            jQuery(document).click();
            jQuery(this).parent().find('.application-menu-dropdown-list').css({'display':'block'});
            jQuery(this).parent().addClass('application-menu-dropdown-region-open');
            //jQuery(this).css({'background-position': '14px bottom', 'border-bottom-right-radius': '0', 'border-bottom-left-radius': '0'});
			jQuery('#dropdown-menu').slideUp(100);
            jQuery("#dropdown-notification-click").css({'background-position': '0 top'});
        }
        else {
            jQuery(this).parent().find('.application-menu-dropdown-list').css({'display':'none'});
            jQuery(this).parent().removeClass('application-menu-dropdown-region-open');
            //jQuery(this).css({'background-position': '14px top', 'border-bottom-right-radius': '20px', 'border-bottom-left-radius': '20px'});
        }
        return false;
    });

    jQuery(document).on('click','.application-menu-dropdown-region>.application-menu-dropdown-list a',function() {
        jQuery(this).parents().eq(3).find('.application-menu-value').text(jQuery(this).text());
        jQuery(this).parents().eq(2).find('.hidden-application-menu-dropdown').val(jQuery(this).text());
        jQuery(this).parents().eq(2).find('.hidden-application-menu-dropdown').attr('data-process', jQuery(this).attr('data-process'));
    });

    jQuery(document).on('click','.checkbox-style',function() {

        if (jQuery(this).parents().eq(2).hasClass('header-table-region')) {
            if (!jQuery(this).hasClass('checkbox-checked')) {
                jQuery(this).addClass('checkbox-checked');
                jQuery(this).parents().eq(3).find('.content-table-area').find('.content-table-region>ul>li').find('.checkbox-style').addClass('checkbox-checked');
                jQuery(this).parents().eq(3).find('.content-table-area').find('.content-table-region>ul>li').find('.hidden-checkbox-val').val('true');

            } else {
                jQuery(this).removeClass('checkbox-checked');
                jQuery(this).parents().eq(3).find('.content-table-area').find('.content-table-region>ul>li').find('.checkbox-style').removeClass('checkbox-checked');
                jQuery(this).parents().eq(3).find('.content-table-area').find('.content-table-region>ul>li').find('.hidden-checkbox-val').val('');
            }
        }
        else {

            if (!jQuery(this).hasClass('checkbox-checked')) {
                jQuery(this).addClass('checkbox-checked');
                jQuery(this).parent().find('.hidden-checkbox-val').val('true');
                if (!jQuery(this).parents().eq(2).hasClass('content-table-region-nested')) {
                    jQuery(this).parents().eq(2).nextAll().find('.checkbox-style').addClass('checkbox-checked');
                    jQuery(this).parents().eq(2).nextAll().find('.hidden-checkbox-val').val('true');
                }

                var all_content_table_region = 0;
                jQuery(this).parents().eq(5).find('.content-table-region').find('.checkbox-style').each(function() {
                    if (jQuery(this).hasClass('checkbox-checked')) {
                        all_content_table_region++;
                    }
                });
                if (all_content_table_region == jQuery(this).parents().eq(5).find('.content-table-region').size()) {
                    jQuery('.checkbox-checkall,#checkall').addClass('checkbox-checked');
                }
            }
            else {
                jQuery(this).removeClass('checkbox-checked');
                jQuery(this).parent().find('.hidden-checkbox-val').val('');
                if (!jQuery(this).parents().eq(2).hasClass('content-table-region-nested')) {
                    jQuery(this).parents().eq(2).nextAll().find('.checkbox-style').removeClass('checkbox-checked');
                    jQuery(this).parents().eq(2).nextAll().find('.hidden-checkbox-val').val('');
                }
                var flag = jQuery(this).parents().eq(3).find('.content-table-region-nested').size();
                jQuery(this).parents().eq(3).find('.content-table-region-nested').find('.checkbox-style').each(function() {
                    if (!jQuery(this).hasClass('checkbox-checked')) {
                        --flag;
                    }
                });
                if (flag < jQuery(this).parents().eq(3).find('.content-table-region-nested').size()) {
                    jQuery(this).parents().eq(3).find('.content-table-region').first().find('.checkbox-style').removeClass('checkbox-checked');
                    jQuery(this).parents().eq(3).find('.content-table-region').first().find('.hidden-checkbox-val').val('');
                }

                var all_content_table_region = jQuery(this).parents().eq(5).find('.content-table-region').size();
                jQuery(this).parents().eq(5).find('.content-table-region').find('.checkbox-style').each(function() {
                    if (!jQuery(this).hasClass('checkbox-checked')) {
                        all_content_table_region--;
                    }
                });
                if (all_content_table_region < jQuery(this).parents().eq(5).find('.content-table-region').size()) {
                    jQuery('.checkbox-checkall,#checkall').removeClass('checkbox-checked');
                }
            }
        }

    });

    jQuery(document).on('click', '.btn-deletenewtxtinput', function() {
        jQuery(this).parent().remove();
    });
    
    jQuery(document).on('click','.dropdown-menu-normal-value',function () {
        jQuery(document).click();
        if (!jQuery(this).parent().find('.dropdown-menu-normal-list').is(':visible')) {
            jQuery(this).parent().find('.dropdown-menu-normal-list').slideDown(200);
            jQuery(this).addClass('dropdown-menu-normal-value-open');
            //jQuery(this).css({ 'background-position': 'left 20px bottom 0px' });
        }
        else {
            jQuery(this).parent().find('.dropdown-menu-normal-list').slideUp(100);
            jQuery(this).removeClass('dropdown-menu-normal-value-open');
            //jQuery(this).css({ 'background-position': 'left 20px top 0px' });
        }
        return false;
    });

    jQuery(document).click(function () {
        jQuery('.dropdown-menu-normal-list').slideUp();
        jQuery('.dropdown-menu-normal-value').removeClass('dropdown-menu-normal-value-open');
        //jQuery('.dropdown-menu-normal-value').css({ 'background-position': 'left 20px top 0px' });
    });

    jQuery('.dropdown-menu-normal-list>ul>li>a').click(function () {
       jQuery(this).parents('.dropdown-menu-normal').find('.dropdown-menu-normal-value').text(jQuery(this).text());
       jQuery(this).parents('.dropdown-menu-normal').find('.hidden-dropdown-menu-normal').val(jQuery(this).text());
    });

    /*jQuery(document).on('mouseover','.txtinput-normal-with-icon-content',function() {
        jQuery(this).find('.txtinput-normal-with-icon-content-icon').css({'background-color': '#bbbbbb', 'color': '#fff'});
        jQuery(this).find('.txtinput-normal-with-icon').css({'border-color': '#bbbbbb'});
    })
	
	jQuery(document).on('mouseleave','.txtinput-normal-with-icon-content',function() {
        if (jQuery(this).parent().find('.txtinput-normal-with-icon').is(":focus")) {
            jQuery(this).parent().find('.txtinput-normal-with-icon-content-icon').css({'background-color': '#47c2b6', 'color': '#fff'});
            jQuery(this).parent().find('.txtinput-normal-with-icon').css({'border-color': '#47c2b6'});
        }
        else {
            jQuery(this).parent().find('.txtinput-normal-with-icon-content-icon').css({'background-color': '#dddddd', 'color': '#bbbbbb'});
            jQuery(this).parent().find('.txtinput-normal-with-icon').css({'border-color': '#dddddd'});
        }
    });

    jQuery(document).on('focusin','.txtinput-normal-with-icon',function() {
        jQuery(this).parent().find('.txtinput-normal-with-icon-content-icon').css({'background-color': '#47c2b6', 'color': '#fff'});
        jQuery(this).css({'border-color': '#47c2b6'});
    });
	jQuery(document).on('focusout','.txtinput-normal-with-icon',function() {
        jQuery(this).parent().find('.txtinput-normal-with-icon-content-icon').css({'background-color': '#dddddd', 'color': '#bbbbbb'});
        jQuery(this).css({'border-color': '#dddddd'});
    });

    jQuery(document).on('click','.txtinput-with-icon-i',function() {
        jQuery(this).parent().find('.txtinput-normal-with-icon').focus();
    });*/

    jQuery(document).on('click', '.select-switch-text', function() {
        jQuery(this).parent().find('.select-switch-text ').removeClass('select-switch-text-active');
        jQuery(this).addClass('select-switch-text-active');
        jQuery(this).parent().find('.hidden-select-switch-text').val(jQuery(this).text());
    });


    jQuery(document).on('mouseover', '.media-file-added-region', function() {
        jQuery(this).find('.delete-media-file-from-list').show();
    }).on('mouseleave', '.media-file-added-region', function() {
        jQuery(this).find('.delete-media-file-from-list').hide();
    });

    jQuery(document).on('click','.btn-addcategory-box-left-column',function() {
        if (!jQuery(this).parent().parent().find('.add-category-left-column-region').is(':visible')) {
            jQuery(this).parent().parent().find('.add-category-left-column-region').slideDown();
            $('body').scrollTo('.add-category-left-column-region', {duration: 'slow'});
        }
        else {
            jQuery(this).parent().parent().find('.add-category-left-column-region').slideUp();
        }
    });

    //jQuery(document).on('click','.btn-box-left-column-add-tag', function () {
    //    if (jQuery(this).parent().find('.txtinput-small-add-tag').val() != "") {
    //        jQuery(this).parent().parent().find('.tags-added-by-user').append('<a><span>x</span>' + jQuery(this).parent().find('.txtinput-small-add-tag').val() + '</a>');
    //        jQuery(this).parent().find('.txtinput-small-add-tag').val('');
    //    }
    //});

    //jQuery(document).on('click','.tags-added-by-user>a>span', function () {
    //    jQuery(this).parent().remove();
    //});

    /*jQuery(document).click(function () {
     jQuery('.tags-added-earlier-content').slideUp();
     jQuery('.tags-added-earlier-menu').css({ 'background-position': '14px top', 'border-bottom-right-radius': '20px', 'border-bottom-left-radius': '20px' });
     });*/

    jQuery(document).on('click','.tags-added-earlier-menu',function() {
        if (!jQuery(this).parent().find('.tags-added-earlier-content').is(':visible')) {
            jQuery(this).parent().find('.tags-added-earlier-content').slideDown();
            jQuery(this).css({'background-position': '14px bottom', 'border-bottom-right-radius': '0', 'border-bottom-left-radius': '0'});
        }
        else {
            jQuery(this).parent().find('.tags-added-earlier-content').slideUp();
            jQuery(this).css({'background-position': '14px top', 'border-bottom-right-radius': '20px', 'border-bottom-left-radius': '20px'});
        }
        return false;
    });

    jQuery(document).on('click','.checkbox-tag',function() {
        if (!jQuery(this).hasClass('checkbox-tag-checked')) {
            jQuery(this).addClass('checkbox-tag-checked');
            jQuery(this).parent().css({'background-color': '#47c2b6', 'color': '#fff', 'border-color': '#47c2b6'});
            jQuery(this).parent().find('.hidden-checkbox-tag-val').val('true');
        }
        else {
            jQuery(this).removeClass('checkbox-tag-checked');
            jQuery(this).parent().css({'background-color': '#eeeeee', 'color': '#666666', 'border-color': '#dddddd'});
            jQuery(this).parent().find('.hidden-checkbox-tag-val').val('');
        }
        return false;
    });

    jQuery(document).on('click','.btn-modal-choose-img',function() {
        jQuery('.modal-input-choose-file').click();
    });

    jQuery(document).on('click', '.item-file-modal-footer-region', function() {
        jQuery(this).addClass('item-file-modal-footer-region-selected');
    });

    jQuery(document).on('click', '.btn-delete-modal-files', function() {
        jQuery(this).parent().parent().parent().find('.item-file-modal-footer-region-selected').remove();
    });

    jQuery(document).on('append','.selected-items-content',function(){
            '<div class="item-file-modal-footer-region">'
            + '<div class="item-file-modal-footer-content">'
            + '<div class="item-file-modal-footer">'
            + '<img alt="itemname" src="otherimages/item-footer-modal-img1.png">'
            + '</div>'
            + '</div>'
            + '</div>'
	});

    /*jQuery('.uploaded-img-region').mouseover(function () {
     jQuery(this).find('.selected-hover-region').css({ 'background-position': 'left bottom' }).show();
     }).mouseleave(function () {
     jQuery(this).find('.selected-hover-region').hide();
     });*/



    //jQuery(document).on('click','.selected-hover-region-unselect', function () {
    //    jQuery(this).parent().find('.selected-hover-region').removeClass('selected-hover-region-delete selected-hover-region-unselect').hide();
    //    jQuery(this).parent().css({ 'border-color': '#fbfbfb' });
    //});

    //jQuery(document).on('click','.selected-hover-region-delete', function () {
    //    jQuery(this).parent().parent().remove();
    //});

    //jQuery(document).on('mouseover','.uploaded-img-region', function () {
    //    if (jQuery(this).find('.selected-hover-region').hasClass('selected-hover-region-select') || jQuery(this).find('.selected-hover-region').hasClass('selected-hover-region-unselect')) {
    //        jQuery(this).find('.selected-hover-region').removeClass('selected-hover-region-select').addClass('selected-hover-region-unselect');
    //    }
    //    //else {
    //    //    jQuery(this).find('.selected-hover-region').css({ 'background-position': 'left bottom' }).addClass('selected-hover-region-delete').show();
    //    //}
    //}).on('mouseleave','.uploaded-img-region', function () {
    //    if (jQuery(this).find('.selected-hover-region').hasClass('selected-hover-region-unselect') || jQuery(this).find('.selected-hover-region').hasClass('selected-hover-region-select')) {
    //        jQuery(this).find('.selected-hover-region').removeClass('selected-hover-region-unselect').addClass('selected-hover-region-select');
    //    }
    //    //else {
    //    //    jQuery(this).find('.selected-hover-region').removeClass('selected-hover-region-delete').hide();
    //    //}
    //});

    jQuery(document).on('mouseover', '.uploaded-img-region', function() {
        if (!jQuery(this).find('.selected-hover-region').hasClass('selected-hover-region-select') && !jQuery(this).find('.selected-hover-region').hasClass('selectedclick')) {
            jQuery(this).find('.selected-hover-region').addClass('selected-hover-region-select').show();
        }
        if (jQuery(this).find('.selected-hover-region').hasClass('selected-hover-region-select') && !jQuery(this).find('.selected-hover-region').hasClass('selectedclick')) {
            jQuery(this).find('.selected-hover-region').show();
        }
        if (jQuery(this).find('.selected-hover-region').hasClass('selected-hover-region-select') && jQuery(this).find('.selected-hover-region').hasClass('selectedclick')) {
            jQuery(this).find('.selected-hover-region').removeClass('selected-hover-region-select').addClass('selected-hover-region-unselect').show();
        }
    }).on('mouseleave', '.uploaded-img-region', function() {
        if (!jQuery(this).find('.selected-hover-region').hasClass('selectedclick')) {
            jQuery(this).find('.selected-hover-region').hide();
        }
        if (jQuery(this).find('.selected-hover-region').hasClass('selected-hover-region-unselect') && jQuery(this).find('.selected-hover-region').hasClass('selectedclick')) {
            jQuery(this).find('.selected-hover-region').removeClass('selected-hover-region-unselect').addClass('selected-hover-region-select').show();
        }
    });

    jQuery(document).on('click', '.uploaded-img-region', function() {
        if (!jQuery(this).find('.selected-hover-region').hasClass('selectedclick')) {
            jQuery(this).find('.selected-hover-region').addClass('selected-hover-region-select').show();
            jQuery(this).css({'border-color': '#47c2b6'});
            jQuery(this).find('.selected-hover-region').addClass('selectedclick');
        }
        else {
            jQuery(this).find('.selected-hover-region').removeClass('selected-hover-region-select');
            jQuery(this).find('.selected-hover-region').removeClass('selected-hover-region-unselect');
            jQuery(this).css({'border-color': '#fbfbfb'});
            jQuery(this).find('.selected-hover-region').removeClass('selectedclick');
        }
    });

    $(document).on('click',".fancybox-manual-add-media",function() {
        $.fancybox.open({
            href: 'modal-add-media-images.html',
            type: 'iframe',
            padding: 0,
            closeBtn: false,
            closeClick: true,
            width: screen.width,
            height: screen.height
        });
    });

    jQuery(document).on('click','.close-modal-add-media',function() {
        parent.$.fancybox.close();
    });

    jQuery(document).on('click','.btn-edit-date-time-publish-post',function() {
        if (jQuery(this).parent().find('.date-time-publish-post-date-and-text-content').is(':visible'))
        {
            jQuery(this).parent().find('.date-time-publish-post-date-and-text-content').hide();
            jQuery(this).parent().find('.txtinput-calender-published-post-content').slideDown(400);
            jQuery(this).css({'background-position': 'left bottom'});
        }
        else if (jQuery(this).parent().find('.txtinput-calender-published-post-content').is(':visible')) {
            jQuery(this).parent().find('.txtinput-calender-published-post-content').hide();
            jQuery(this).parent().find('.date-time-publish-post-date-and-text-content').slideDown(400);
            jQuery(this).css({'background-position': 'left top'});
        }
        return false;
    });

    jQuery(document).on('click','.btn-spinner-next-prev',function() {
        var txtinput_normal_number_spinner = parseInt(jQuery(this).parent().parent().find('.txtinput-normal').val());
        var txtinput_sliderno_val = parseInt(jQuery(this).parent().parent().find('.txtinput-normal').attr('data-sliderno'));
        //jQuery(this).parent().parent().find('.txtinput-normal').addClass('txtinput-normal-number');
        if (jQuery(this).parent().parent().find('.txtinput-normal').val() == "") {
            txtinput_normal_number_spinner = 0;
        }
        if (jQuery(this).hasClass('btn-spinner-next-prev-up')) {
            jQuery(this).parent().parent().find('.txtinput-normal').val(txtinput_normal_number_spinner + 1);
        }
        if (jQuery(this).hasClass('btn-spinner-next-prev-down') && (jQuery(this).parent().parent().find('.txtinput-normal').val() >= 1)) {
            var new_val = txtinput_normal_number_spinner - 1;
            if (new_val < 1) {
                jQuery(this).parent().parent().find('.txtinput-normal').val('1');
            }
            else {
                jQuery(this).parent().parent().find('.txtinput-normal').val(new_val);
            }
        }
        jQuery('.txtinput-sliderno').keyup();
    });

    jQuery(document).on('keyup', '.txtinput-sliderno', function() {
        var txtinput_sliderno_val = jQuery(this).attr('data-sliderno');
        var txtinput_sliderno_user_val = jQuery(this).val().trim();
        if (parseInt(txtinput_sliderno_user_val) > parseInt(txtinput_sliderno_val)) {
            jQuery(this).val(txtinput_sliderno_val);
        }
        else {
            jQuery(this).val(txtinput_sliderno_user_val);
        }
        if (txtinput_sliderno_user_val == '0')
        {
            jQuery(this).val('1');
        }
    });

    jQuery(document).on('keyup','.txtinput-normal-number-images-slider',function() {
        if (jQuery(this).val() == "") {
            jQuery(this).removeClass('txtinput-normal-number');
        }
        else
        {
            jQuery(this).addClass('txtinput-normal-number');
        }

    });

    jQuery(document).on('click', '.btn-delete-group-txtinputs-organizers,.btn-delete-group-txtinputs-speakers', function() {
        jQuery(this).parent().remove();
    });

    jQuery(document).on('click','.upload-image-event-region',function() {
        jQuery(this).parent().find('.hidden-upload-image-event-file').click();
    });

    //jQuery(document).on('click', '.upload-image-ads-view-region-hover', function () {
    //    jQuery(this).parent().find('img').attr({'src':'','alt':''});
    //});

    jQuery(document).on('click','.btn-image-view-user-profile-content',function() {
        jQuery(this).parent().find('.hidden-image-view-user-profile').click();
    });

    jQuery(document).on('click','.btn-upload-click',function() {
        jQuery(this).parent().find('input[type=file]').click();
    });

    jQuery(document).on('keyup', '.time-txtinput-small-hours', function() {
        if (jQuery(this).val().trim() > 12 || jQuery(this).val().trim() < 1) {
            jQuery(this).val('01');
        }
    });

    jQuery(document).on('keyup', '.time-txtinput-small-minutes', function() {
        if (jQuery(this).val().trim() > 59) {
            jQuery(this).val('00');
        }
    });

    jQuery(document).on('click', '.time-select-updown-up', function() {
        var input_hours_minutes_focus = jQuery(this).parent().parent().find('.time-txtinput-small-focus');

        if (input_hours_minutes_focus.hasClass('time-txtinput-small-hours')) {
            var hours_old = input_hours_minutes_focus.val();
            var hours_new = parseInt(hours_old) + 1;
            if (hours_new < 10) {
                input_hours_minutes_focus.val('0' + hours_new);
            }
            else {
                input_hours_minutes_focus.val(hours_new);
            }
            jQuery(this).parent().parent().find('.time-txtinput-small-hours').keyup();
        }

        if (input_hours_minutes_focus.hasClass('time-txtinput-small-minutes')) {

            var minutes_old = input_hours_minutes_focus.val();
            var minutes_new = parseInt(minutes_old) + 1;

            if (minutes_new < 10) {
                input_hours_minutes_focus.val('0' + minutes_new);
            }
            else {
                input_hours_minutes_focus.val(minutes_new);
            }
            if (minutes_new > 59) {
                input_hours_minutes_focus.val('00');
                var input_hours = jQuery(this).parent().parent().find('.time-txtinput-small-hours');
                var input_hours_val = input_hours.val();
                var input_hours_val_new = parseInt(input_hours_val) + 1;
                if (input_hours_val_new < 10) {
                    input_hours.val('0' + input_hours_val_new);
                }
                else {
                    input_hours.val(input_hours_val_new);
                }
                jQuery(this).parent().parent().find('.time-txtinput-small-hours').keyup();
            }
        }
    });

    jQuery(document).on('click', '.time-select-updown-down', function() {
        var input_hours_minutes_focus = jQuery(this).parent().parent().find('.time-txtinput-small-focus');

        if (input_hours_minutes_focus.hasClass('time-txtinput-small-hours')) {
            var hours_old = input_hours_minutes_focus.val();
            var hours_new = parseInt(hours_old) - 1;
            if (hours_new < 10) {
                input_hours_minutes_focus.val('0' + hours_new);
            }
            else {
                input_hours_minutes_focus.val(hours_new);
            }
            if (hours_new < 1) {
                input_hours_minutes_focus.val('12');
            }

            jQuery(this).parent().parent().find('.time-txtinput-small-hours').keyup();
        }

        if (input_hours_minutes_focus.hasClass('time-txtinput-small-minutes')) {

            var minutes_old = input_hours_minutes_focus.val();
            var minutes_new = parseInt(minutes_old) - 1;

            if (minutes_new < 10) {
                input_hours_minutes_focus.val('0' + minutes_new);
            }
            else {
                input_hours_minutes_focus.val(minutes_new);
            }
            if (minutes_new < 0) {
                input_hours_minutes_focus.val('59');

                var input_hours = jQuery(this).parent().parent().find('.time-txtinput-small-hours');
                var input_hours_val = input_hours.val();
                var input_hours_val_new = parseInt(input_hours_val) - 1;
                if (input_hours_val_new < 10) {
                    input_hours.val('0' + input_hours_val_new);
                }
                else {
                    input_hours.val(input_hours_val_new);

                }
                if (input_hours_val_new < 1) {
                    input_hours.val('12');
                }
                jQuery(this).parent().parent().find('.time-txtinput-small-hours').keyup();
            }

        }
    });

    function time() {
        var currentTime = new Date();
        var hours = currentTime.getHours();
        var minutes = currentTime.getMinutes();

        var hourview = 0;
        if (hours >= 12) {
            hourview = hours - 12;
            jQuery('.select-timetype-text').removeClass('select-switch-text-active');
            jQuery('.select-timetype-text-pm').addClass('select-switch-text-active');
        }
        if (hours < 12) {
            hourview = hours;
            jQuery('.select-timetype-text').removeClass('select-switch-text-active');
            jQuery('.select-timetype-text-am').addClass('select-switch-text-active');
        }

        if (hourview < 10) {
            hourview = '0' + hourview;
        }

        var minutesview;
        if (minutes < 10) {
            minutesview = '0' + minutes;
        }
        else {
            minutesview = minutes;
        }

        jQuery('.time-txtinput-small-hours').val(hourview);
        jQuery('.time-txtinput-small-minutes').val(minutesview);
    }

    time();

    jQuery(document).on('click', '.time-txtinput-small', function() {
        jQuery(this).parent().find('.time-txtinput-small').removeClass('time-txtinput-small-focus');
        jQuery(this).addClass('time-txtinput-small-focus');
    });

    jQuery(document).on('click', '.btn-upload-special-img', function() {
        jQuery(this).parent().find('.hidden-special-img').click();
    });

    //jQuery(document).on('click', '.btn-delete-post', function () {
    //    var thisdeleteparent = jQuery(this).parents().eq(5);
    //    var thisdelete = jQuery(this).parents().eq(6);
    //    var thisdeletemedia = jQuery(this).parents().eq(5);

    //    if (confirm("هل تريد الحذف بالتأكيد")) {
    //        if (jQuery(this).hasClass('btn-delete-post-addmedia')) {
    //            thisdeletemedia.slideUp(200);
    //            setTimeout(function () {
    //                thisdeletemedia.remove();
    //            }, 400);
    //        }
    //        else {
    //            if (thisdeleteparent.hasClass('content-table-region-nested')) {
    //                thisdeleteparent.slideUp(200);
    //                setTimeout(function () {
    //                    thisdeleteparent.remove();
    //                }, 400);
    //            }
    //            else {
    //                thisdelete.slideUp(200);
    //                setTimeout(function () {
    //                    thisdelete.remove();
    //                }, 400);
    //            }
    //        }
    //    }
    //    return false;
    //});

    jQuery(document).on('click', '.confirm-fault-msg-region', function() {
        jQuery(this).slideUp(200);
    });

    //jQuery('.txtinput-calendar-date').datepicker({
    //  dateFormat: 'mm/dd/yy'
    //});
    
    //jQuery(document).on('focus', '.txtinput-calendar-date', function(e) {
    //    jQuery(this).datepicker({
    //        dateFormat: 'mm/dd/yy'
            
    //    });
    //});

    /*
    jQuery(document).on('focus', '.txtinput-calendar-date', function () {
        jQuery(this).datepicker({
            prevText: '<i class="fa fa-chevron-left"></i>',
            nextText: '<i class="fa fa-chevron-right"></i>',
            showButtonPanel: false,
            dateFormat: 'mm/dd/yy',
            changeMonth: true,
            changeYear: true,
            onSelect: function (dateText, inst) {
                setTimeout(function () {
                    jQuery('.ui-datepicker').find('.ui-state-default').removeClass('ui-state-highlight');
                }, 50);
            },
            beforeShow: function (input, inst) {
                setTimeout(function () {
                    if (jQuery('.ui-datepicker').find('a.ui-state-active').is(':visible')) {
                        jQuery('.ui-datepicker').find('a.ui-state-default').removeClass('ui-state-highlight');
                    }
                }, 50);
            }
        });
    });

    jQuery(document).on('focus', '.txtinput-calendar-date-nochange', function () {
        jQuery(this).datepicker({
            prevText: '<i class="fa fa-chevron-left"></i>',
            nextText: '<i class="fa fa-chevron-right"></i>',
            dateFormat: 'mm/dd/yy',
            showButtonPanel: false,
            onSelect: function (dateText, inst) {
                setTimeout(function () {
                    jQuery('.ui-datepicker').find('.ui-state-default').removeClass('ui-state-highlight');
                }, 50);
            },
            beforeShow: function (input, inst) {
                setTimeout(function () {
                    if (jQuery('.ui-datepicker').find('a.ui-state-active').is(':visible')) {
                        jQuery('.ui-datepicker').find('a.ui-state-default').removeClass('ui-state-highlight');
                    }
                }, 50);
            }
        });
    });

    jQuery(document).on('focus', '.txtinput-calendar-time', function () {
        jQuery(this).timepicker({
            beforeShow: function (input, inst) {
                var newclass = 'smart-forms';
                var smartpikr = inst.dpDiv.parent();
                if (!smartpikr.hasClass('smart-forms')) {
                    inst.dpDiv.wrap('<div class="' + newclass + '"></div>');
                }
            }
        });
    });

    jQuery(document).on('focus', '.txtinput-calendar-datetime', function () {
        jQuery(this).datetimepicker({
            prevText: '<i class="fa fa-chevron-left"></i>',
            nextText: '<i class="fa fa-chevron-right"></i>',
            beforeShow: function (input, inst) {
                var newclass = 'smart-forms';
                var smartpikr = inst.dpDiv.parent();
                if (!smartpikr.hasClass('smart-forms')) {
                    inst.dpDiv.wrap('<div class="' + newclass + '"></div>');
                }
                setTimeout(function () {
                    if (jQuery('.ui-datepicker').find('a.ui-state-active').is(':visible')) {
                        jQuery('.ui-datepicker').find('a.ui-state-default').removeClass('ui-state-highlight');
                    }
                }, 50);
            },
            changeMonth: true,
            changeYear: true,
            onSelect: function (dateText, inst) {
                setTimeout(function () {
                    jQuery('.ui-datepicker').find('.ui-state-default').removeClass('ui-state-highlight');
                }, 50);
            }
        });
    });

    jQuery(document).on('focus', '.txtinput-calendar-datetime-nochange', function () {
        jQuery(this).datetimepicker({
            prevText: '<i class="fa fa-chevron-left"></i>',
            nextText: '<i class="fa fa-chevron-right"></i>',
            dateFormat: 'mm/dd/yy',
            beforeShow: function (input, inst) {
                var newclass = 'smart-forms';
                var smartpikr = inst.dpDiv.parent();
                if (!smartpikr.hasClass('smart-forms')) {
                    inst.dpDiv.wrap('<div class="' + newclass + '"></div>');
                }
                setTimeout(function () {
                    if (jQuery('.ui-datepicker').find('a.ui-state-active').is(':visible')) {
                        jQuery('.ui-datepicker').find('a.ui-state-default').removeClass('ui-state-highlight');
                    }
                }, 50);
            },
            onSelect: function (dateText, inst) {
                setTimeout(function () {
                    jQuery('.ui-datepicker').find('.ui-state-default').removeClass('ui-state-highlight');
                }, 50);
            }

        });
    });

    jQuery(document).on('focus', '.txtinput-calendar-from', function () {
        jQuery(this).datepicker({
            prevText: '<i class="fa fa-chevron-left"></i>',
            nextText: '<i class="fa fa-chevron-right"></i>',
            onClose: function (selectedDate) {
                jQuery(this).parent().find(".txtinput-calendar-to").datepicker("option", "minDate", selectedDate);
            }
            , dateFormat: 'mm/dd/yy',
            changeMonth: true,
            changeYear: true
        });
    });

    jQuery(document).on('focus', '.txtinput-calendar-to', function () {
        jQuery(this).datepicker({
            prevText: '<i class="fa fa-chevron-left"></i>',
            nextText: '<i class="fa fa-chevron-right"></i>',
            onClose: function (selectedDate) {
                jQuery(this).parent().find(".txtinput-calendar-from").datepicker("option", "MaxDate", selectedDate);
            }
			, dateFormat: 'mm/dd/yy'
			, minDate: jQuery(this).parent().find(".txtinput-calendar-from").val(),
			changeMonth: true,
			changeYear: true
        });
    });
    */

    //new datetime
    
    /*jQuery(document).on('focus', '.txtinput-calendar-datetime,.txtinput-calendar-datetime-nochange', function (e) {
        jQuery(this).datetimepicker({
            language:  'ar',
            weekStart: 6,
            todayBtn:  1,
            autoclose: 1,
            todayHighlight: 1,
            startView: 2,
            // forceParse: 0,
            showMeridian: 1,
            format: "mm/dd/yyyy hh:ii"
        });
    });
    
    jQuery(document).on('focus', '.txtinput-calendar-date,.txtinput-calendar-date-nochange', function (e) {
        jQuery(this).datetimepicker({
            language:  'ar',
             weekStart: 6,
             todayBtn:  1,
             autoclose: 1,
             todayHighlight: 1,
             startView: 2,
             minView: 2,
             forceParse: 0,
             format: "mm/dd/yyyy"
        });
    });
    
    jQuery(document).on('focus', '.txtinput-calendar-time', function (e) {
        jQuery(this).datetimepicker({
             language:  'ar',
             weekStart: 6,
             todayBtn:  1,
             autoclose: 1,
             todayHighlight: 1,
             startView: 1,
             minView: 0,
             maxView: 1,
             forceParse: 0,
             showMeridian: 1,
             format: "hh:ii"
        });
    });

    jQuery(document).on('focus', '.txtinput-calendar-from', function (e) {
        jQuery(this).datetimepicker({
            language:  'ar',
             weekStart: 6,
             todayBtn:  1,
             autoclose: 1,
             todayHighlight: 1,
             startView: 2,
             minView: 2,
             forceParse: 0,
             format: "mm/dd/yyyy"
        });
    });

    jQuery(document).on('focus', '.txtinput-calendar-to', function (e) {
        jQuery(this).datetimepicker({
            language:  'ar',
             weekStart: 6,
             todayBtn:  1,
             autoclose: 1,
             todayHighlight: 1,
             startView: 2,
             minView: 2,
             forceParse: 0,
             format: "mm/dd/yyyy"
        });
    });*/
    
    jQuery('.txtdatetime').datetimepicker({
        format: "MM/DD/YYYY hh:mm A"
    });
    
    jQuery('.txtdate').datetimepicker({
        pickTime: false,
        format: "MM/DD/YYYY"
    });
    
    jQuery('.txttime').datetimepicker({
        pickDate: false,
        format: "hh:mm A"
    });
    
    jQuery('.txtdatefrom').datetimepicker({
        pickTime: false,
        format: "MM/DD/YYYY"
    });
    
    jQuery('.txtdateto').datetimepicker({
        pickTime: false,
        format: "MM/DD/YYYY"
    });
    
    jQuery(".txtdatefrom").on("dp.change",function (e) {
       jQuery('.txtdateto').data("DateTimePicker").setMinDate(e.date);
    });
    jQuery(".txtdateto").on("dp.change",function (e) {
       jQuery('.txtdatefrom').data("DateTimePicker").setMaxDate(e.date);
    });
    
    jQuery(document).on('focus','.txtdatedob',function(){
        jQuery(this).datetimepicker({
            pickTime: false,
            format: "MM/DD/YYYY"
        }).data("DateTimePicker").setMaxDate(new Date());
    });

    jQuery(document).on('focus','.txtdatefrom2',function(){
        jQuery(this).datetimepicker({
            pickTime: false,
            format: "MM/DD/YYYY"
        }).data("DateTimePicker").setMinDate(new Date());
    });

    jQuery('.txtdateto2').datetimepicker({
        pickTime: false,
        format: "MM/DD/YYYY"
    });

    jQuery(".txtdatefrom2").on("dp.change",function (e) {
       jQuery('.txtdateto2').data("DateTimePicker").setMinDate(e.date);
    });
    jQuery(".txtdateto2").on("dp.change",function (e) {
       jQuery('.txtdatefrom2').data("DateTimePicker").setMaxDate(e.date);
    });
    
    //jQuery(document).on('click', '.delete-media-file-from-list', function () {
    //    var thisclick = jQuery(this).parent();
    //    thisclick.slideUp(200);
    //    setTimeout(function () {
    //        thisclick.remove();
    //    },400);
    //});

    //jQuery(document).on('click', '.btn-active-all-menu', function () {
    //    jQuery(this).parents().eq(6).find('.content-table-area>ul>li>.content-table-region>ul').each(function () {
    //        //li-table-status
    //        if (jQuery(this).find('.hidden-checkbox-val').val().trim().length > 0)
    //        {
    //            jQuery(this).find('.li-table-status').text('فعال');
    //        }
    //    });
    //    jQuery('.checkbox-checkall').removeClass('checkbox-checked');
    //    jQuery('.checkbox-style').removeClass('checkbox-checked');
    //    jQuery('.hidden-checkbox-val').val('');
    //});

    //jQuery(document).on('click', '.btn-inactive-all-menu', function () {
    //    jQuery(this).parents().eq(6).find('.content-table-area>ul>li>.content-table-region>ul').each(function () {
    //        //li-table-status
    //        if (jQuery(this).find('.hidden-checkbox-val').val().trim().length > 0) {
    //            jQuery(this).find('.li-table-status').text('غير فعال');
    //        }
    //    });
    //    jQuery('.checkbox-checkall').removeClass('checkbox-checked');
    //    jQuery('.checkbox-style').removeClass('checkbox-checked');
    //    jQuery('.hidden-checkbox-val').val('');
    //});

    /*jQuery(document).on('click', '.btn-delete-all-menu', function () {
     jQuery(this).parents().eq(6).find('.content-table-area>ul>li>.content-table-region>ul>.first-li-table-check').each(function () {
     if (jQuery(this).find('.hidden-checkbox-val').val().trim().length > 0) {
     if (jQuery(this).parent().parent().hasClass('content-table-region-nested')) {
     jQuery(this).parent().parent().remove();
     }
     else {
     jQuery(this).parents().eq(2).remove();
     }
     }
     jQuery('.checkbox-checkall').removeClass('checkbox-checked');
     });
     });*/


    /*jQuery(document).on('keyup','#search-txt',function() {
        var txtinput = jQuery(this).val();
        jQuery('#main-menu>ul>li').each(function() {
            if (jQuery(this).find('a>span').text().search(txtinput) >= 0) {
                jQuery(this).show();
            }
            else {
                jQuery(this).hide();
            }
        });
    });*/
	
	jQuery(document).on('keyup','#search-txt',function () {
        var txtinput = jQuery(this).val();
        var regexp_open = /\(/;
        var regexp_close = /\)/;
        if (txtinput.search('script') >= 0 || (regexp_open.test(txtinput) == true) || (regexp_close.test(txtinput) == true)) {
            jQuery(this).val('');
        }
        else {
            jQuery('#main-menu>ul>li').each(function () {
                
                if (jQuery(this).find('a>span').text().search(txtinput) >= 0) {
                    jQuery(this).show();
                }
                else {
                    jQuery(this).hide();
                }
            });
        }
    });

    jQuery(document).on('keyup','input[type=text]',function () {
        var txtinput = jQuery(this).val();
        if (txtinput.search('script') >= 0) {
            jQuery(this).val('');
        }
    });

    jQuery('.counter-txtarea-chars-input-maxlength').each(function () {
        jQuery(this).text(jQuery(this).parents('.txtinput-normal-content,.txtarea-normal-content').find('.counter-txtarea').attr('maxlength'));
    });
    jQuery('.counter-txtarea-chars-number').each(function () {
        jQuery(this).text(jQuery(this).parents('.txtinput-normal-content,.txtarea-normal-content').find('.counter-txtarea').val().length);
    });


    jQuery(document).on('keyup', '.counter-txtarea', function () {
        var counter_txtarea_maxlength = jQuery(this).attr('maxlength');
        var counter_txtarea_currentlength = jQuery(this).val().length;

        jQuery(this).parent().find('.counter-txtarea-chars-number').text(jQuery(this).val().length);

        if ((counter_txtarea_maxlength - counter_txtarea_currentlength) <= 5) {
            jQuery(this).parent().find('.counter-txtarea-chars-number').addClass('counter-txtarea-chars-number-error');
        }
        else {
            jQuery(this).parent().find('.counter-txtarea-chars-number').removeClass('counter-txtarea-chars-number-error');
        }
    });
	
	jQuery(".tab-content-statistics-region").not(":first").hide();
    jQuery(".tab-yearly-monthly-menu-region li:first").find('.tab-yearly-monthly-menu-text').addClass("yearly-monthly-menu-select");
    jQuery(document).on('click', ".tab-yearly-monthly-menu-region li", function () {
        var index = jQuery(this).parent().find('li').index(this);
        if (!jQuery(this).children('.yearly-monthly-menu-text').hasClass("yearly-monthly-menu-select")) {
            jQuery(".tab-content-statistics-region:visible").hide();
            jQuery(".tab-content-statistics-region").eq(index).show();
            jQuery(".tab-yearly-monthly-menu-region>ul>li").find('.tab-yearly-monthly-menu-text').removeClass("yearly-monthly-menu-select");
            jQuery(this).find('.tab-yearly-monthly-menu-text').addClass("yearly-monthly-menu-select");
        }
        return false;
	 });
	 
	jQuery(document).click(function () {
        jQuery('.dropdown-chart-area ul').slideUp(100);
        jQuery('.dropdown-chart-region').removeClass('dropdown-chart-region-active');
    });

    jQuery(document).on('click', '.dropdown-chart-region', function () {
        jQuery(document).click();
        if (!jQuery(this).parent().find('ul').is(':visible')) {
            jQuery(this).parent().find('ul').css({'display':'block'});
            jQuery(this).addClass('dropdown-chart-region-active');
        }
        else {
            jQuery(this).parent().find('ul').css({'display':'none'});
            jQuery(this).removeClass('dropdown-chart-region-active');
        }
        return false;
    });
    

    jQuery(document).on('click', '.dropdown-chart-area>ul>li>span', function () {
        jQuery(this).parents().eq(2).find('.dropdown-chart-region>span').text(jQuery(this).text());
        jQuery(this).parents().eq(2).find('.hidden-dropdown-chart').val(jQuery(this).text());
    });

    jQuery(document).on('click', '.table-more-icon', function () {
        var indexli = jQuery('.content-table-area>ul>li').index(jQuery(this).parents().eq(3));
        var sizeul = parseInt(jQuery('.content-table-area>ul>li').eq(indexli).find('.content-table-region>ul>li').size() - 1);
        var indexlink = jQuery('.content-table-area>ul>li').eq(indexli).find('.content-table-region>ul>li').index(jQuery('.content-table-area>ul>li').eq(indexli).find('.table-link-icon').parent());

        var i;

        for (i = 1; i < sizeul; i++) {
            if (i == indexlink) {
                continue;
            }
            else {
                jQuery('ul.table-more-details').append(
                    '<li>'
                        + '<h2>' + jQuery('.header-table-region>ul>li').eq(i).text() + '</h2>'
                        + '<h3>' + jQuery('.content-table-area>ul>li').eq(indexli).find('.content-table-region>ul>li').eq(i).text() + '</h3>'
                    + '</li>'
                );
            }
        }

        jQuery('.overlay-region').show();
        jQuery('.modal-region').show();

        jQuery('html,body').animate({ scrollTop: 0 }, 0);

        var screenheight = parseInt(jQuery(window).height());
        var modalheight = parseInt(jQuery('.modal-region').height());

        var topspace;
        if (screenheight > modalheight) {
            topspace = (screenheight - modalheight) / 2;
        }
        else {
            topspace = 50;
        }

        jQuery('body').css({ 'min-height': (modalheight + topspace + 20) });

        jQuery('.modal-region').animate({ top: topspace }, 400);

        return false;
    });

    jQuery(document).on('click', '.modal-close', function () {
        var thiclick = jQuery(this);
        thiclick.parent().parent().animate({ top: '-200%' }, 400);
        setTimeout(function () {
            jQuery('.overlay-region').hide();
            thiclick.parent().parent().hide().find('ul.table-more-details').html('');
            //jQuery('body').css({ 'min-height': 'auto' });
            jQuery('body').removeAttr('style');
            //jQuery('.txtinput-normal').removeClass('error-required required-field');
        }, 600);
        popup_region = false;
    });

    var popup_region = false;

    jQuery(document).on('click', '.overlay-region', function () {
        if (popup_region == false) {
            var thiclick = jQuery('.modal-close');
            thiclick.parent().parent().animate({ top: '-200%' }, 400);
            setTimeout(function () {
                jQuery('.overlay-region').hide();
                jQuery('.modal-region').hide().find('ul.table-more-details').html('');
                jQuery('body').removeAttr('style');
                //jQuery('.txtinput-normal').removeClass('error-required required-field');
            }, 600);
        }
        popup_region = false;
    });

    jQuery(document).on('keyup', function (e) {
        if (e.keyCode == 27) {
            jQuery('.modal-close').click();
        }
    });

    jQuery(".dropdown-menu-normal-list").mCustomScrollbar({
        theme:"minimal-dark"
    });

    jQuery(".select-header").select2({
        dropdownCssClass: 'no-search select-header-custom' 
    });

    jQuery('.chosen-select').select2({
        dropdownCssClass: 'no-search'
    });

    jQuery('.chosen-select-search').select2({
        //dropdownCssClass: 'no-search'
    });

    var ddl_checkbox_list = false;
    jQuery(document).on('click','.dropdown-checkbox-text',function(){
        ddl_checkbox_list = false;
        if(!jQuery(this).parent().hasClass('dropdown-checkbox-region-open'))
        {
            jQuery(this).parent().addClass('dropdown-checkbox-region-open');
            jQuery(this).find('span').removeClass('fa-caret-down').addClass('fa-caret-up');
        }
        else
        {
            jQuery(this).parent().removeClass('dropdown-checkbox-region-open');
            jQuery(this).find('span').removeClass('fa-caret-up').addClass('fa-caret-down');
        }
        return false;
    });

    jQuery(document).on('click','.dropdown-checkbox-list',function(){
        ddl_checkbox_list = true;
        setTimeout(function(){
            ddl_checkbox_list = false;
        },1);
    });

    jQuery(document).on('click','.dropdown-checkbox-list label',function(){
        ddl_checkbox_list = true;
        var ddl_name = jQuery(this).parents('.dropdown-checkbox-region').find('.dropdown-checkbox-text').attr('data-name');
        var checkboxs_checked_size = jQuery(this).parents().eq(2).find('.table-checkbox .checkbox-child:checked').size();
        var ul_li_size = jQuery(this).parents('.dropdown-checkbox-region').find('.dropdown-checkbox-list li').size() -1;
        if(checkboxs_checked_size>=1)
        {
            jQuery(this).parents('.dropdown-checkbox-region').find('.dropdown-checkbox-text h2').text(checkboxs_checked_size+" selected");
        }
        else
        {
            jQuery(this).parents('.dropdown-checkbox-region').find('.dropdown-checkbox-text h2').text(ddl_name);
        }
        if(checkboxs_checked_size==ul_li_size)
        {
            jQuery(this).parents('.dropdown-checkbox-list').find('.checkbox-parent').prop('checked','true');
        }
        else
        {
            jQuery(this).parents('.dropdown-checkbox-list').find('.checkbox-parent').removeAttr('checked');
        }
        
    });

    jQuery('.dropdown-checkbox-list').each(function(){
        var checkboxs_checked_size = jQuery(this).find('.checkbox-child:checked').size();
        var ul_li_size = jQuery(this).parents('.dropdown-checkbox-region').find('.dropdown-checkbox-list li').size() -1;
        if(checkboxs_checked_size==ul_li_size)
        {
            jQuery(this).find('.checkbox-parent').prop('checked','true');
        }
        else
        {
            jQuery(this).find('.checkbox-parent').removeAttr('checked');
        }
    });

    jQuery(document).click(function(){
        if(ddl_checkbox_list == false)
        {
            jQuery('.dropdown-checkbox-region').removeClass('dropdown-checkbox-region-open');
            jQuery('.dropdown-checkbox-text span').removeClass('fa-caret-up').addClass('fa-caret-down');
        }
    });

    jQuery(document).on('click','.checkbox-parent',function(){
        if(jQuery(this).prop('checked')==true)
        {
            jQuery(this).parents('.dropdown-checkbox-list').find('.checkbox-child').each(function(){
                jQuery(this).prop('checked','true');
            });
        }
        else
        {
            jQuery(this).parents('.dropdown-checkbox-list').find('.checkbox-child').each(function(){
                jQuery(this).removeAttr('checked');
            });
        }
    });

    jQuery(document).on('click','#selectall',function(){
        if(jQuery(this).prop('checked')==true)
        {
            jQuery('.view-permissions-table-content>li input[type=checkbox]').each(function(){
                jQuery(this).prop('checked',true);
            });
        }
        else {
            jQuery('.view-permissions-table-content>li input[type=checkbox]').each(function(){
                jQuery(this).removeAttr('checked');
            });
        }
    });

    function checkall(){
        var checkboxs = jQuery('.view-permissions-table-region').find('input[type=checkbox]').size();
        var checkboxs_checked = jQuery('.view-permissions-table-region').find('input[type=checkbox]:checked').size();
        if(checkboxs_checked==checkboxs) {
            jQuery('#selectall').prop('checked',true);
        }
        else
        {
            jQuery('#selectall').removeAttr('checked');
        }
    }

    jQuery(document).on('click','.switch input[type=checkbox]:not(#selectall)',function(){
        checkall();
    });

    jQuery(window).load(function(){
        jQuery('.checkall-row').each(function(){
            if(jQuery(this).parents().eq(2).find('input[type=checkbox]:not(.checkall-row):not(:checked)').length>0)
            {
                jQuery(this).removeAttr('checked');
            }
            else
            {
                jQuery(this).prop('checked',true);
            }
        });
        checkall();
    });

    jQuery(document).on('click','.checkall-row',function(){
        if(jQuery(this).prop('checked')==true)
        {
            jQuery(this).parents().eq(2).find('input[type=checkbox]:not(.checkall-row)').prop('checked',true);
        }
        else
        {
            jQuery(this).parents().eq(2).find('input[type=checkbox]:not(.checkall-row)').removeAttr('checked');
        }
        checkall();
    });

    jQuery(document).on('click','input[type=checkbox]:not(.checkall-row)',function(){
        if(jQuery(this).parents().eq(2).find('input[type=checkbox]:not(.checkall-row):not(:checked)').length>0)
        {
            jQuery(this).parents().eq(2).find('input[type=checkbox].checkall-row').removeAttr('checked');
        }
        else
        {
            jQuery(this).parents().eq(2).find('input[type=checkbox].checkall-row').prop('checked',true);
        }
        checkall();
    });

    jQuery(document).on('click', ".tab-choese>ul li", function () {
        var index = jQuery(".tab-choese>ul li").index(this);
        if (!jQuery(this).hasClass("tab-active")) {
            jQuery(".tab-content:visible").removeClass('tab-content-active');
            jQuery(".tab-content").eq(index).addClass('tab-content-active');
            jQuery(".tab-choese>ul li").removeClass("tab-active");
            jQuery(this).addClass("tab-active");
        }
        return false;
    });

    // for active tab
    jQuery(window).load(function(){
        var lang=jQuery('body').attr('lang');
        if(jQuery('body').attr('lang')=='ar'){
            jQuery('.tab-choese>ul li').last().click();
        }

        jQuery('.video-img-select,.main-branch,.fa-ex-select').change();
    });

    jQuery(document).on('change','.video-img-select',function(){
        if(jQuery(this).val()=="2")
        {
            jQuery('.img-up-choice').removeClass('display-none');
            jQuery('.video-up-choice').addClass('display-none');
        }
        else
        {
            jQuery('.video-up-choice').removeClass('display-none');
            jQuery('.img-up-choice').addClass('display-none');
        }
    });

    jQuery(document).on('change','.main-branch',function(){
        if(jQuery(this).prop('checked')==true)
        {
            jQuery('.elm-branch').addClass('display-none');
            jQuery('.m-b-choise').removeClass('display-none');
        }
        else
        {
            jQuery('.elm-branch').addClass('display-none');
            jQuery('.notmain-choise').removeClass('display-none');
        }
        jQuery('.txtinput-required,.req-custom,.req-branch').removeClass('error-required');
    });

    jQuery(document).on('change','.fa-ex-select',function(){
        if(jQuery(this).val()=="Export")
        {
            jQuery('.elm-branch').addClass('display-none');
            jQuery('.ex-choise').removeClass('display-none');
        }
        else
        {
            jQuery('.elm-branch').addClass('display-none');
            jQuery('.fa-choice').removeClass('display-none');
        }
        jQuery('.txtinput-required,.req-custom,.req-branch').removeClass('error-required');
    });

});


