﻿jQuery(document).ready(function () {

    //var urlreg = /^((https?|ftp):\/\/)?(((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:)*@)?(((\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5]))|((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?)(:\d*)?)(\/((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)+(\/(([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)*)*)?)?(\?((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|[\uE000-\uF8FF]|\/|\?)*)?(\#((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|\/|\?)*)?$/i;

    //var urlreg = /^((http)?(s)?:\/\/)?([\w-]+\.)+[\w-]+(\/[\w- .\/?%&=]*)?$/;

    jQuery(document).on('keydown', '.txtnotnumber', function (event) {
        if (event.altKey == false && event.ctrlKey == false)
        {
            if ((event.keyCode >= 48 && event.keyCode <= 57) || (event.keyCode >= 96 && event.keyCode <= 105) && event.shiftKey== false)
            {
                return false;
            }
            else
            {
                if((event.keyCode >= 65 && event.keyCode <= 90) ||
                (event.keyCode >= 97 && event.keyCode <= 122))
                {}
            }
        }
    });

    jQuery(document).on('keydown', '.txtbox-filter-number,.txtinput-filter-number', function(event) {
    // Allow: backspace, delete, tab, escape, enter and . 190
    if ($.inArray(event.keyCode, [46, 8, 9, 27, 13]) !== -1 ||
            // Allow: Ctrl+A
                    (event.keyCode == 65 && event.ctrlKey === true) ||
                    // Allow: home, end, left, right
                            (event.keyCode >= 35 && event.keyCode <= 39)) {
                // let it happen, don't do anything
                return;
            }
            else {
                // Ensure that it is a number and stop the keypress
                if (event.shiftKey || (event.keyCode < 48 || event.keyCode > 57) && (event.keyCode < 96 || event.keyCode > 105)) {
                    event.preventDefault();
                }
            }
    });

    jQuery(document).on("keypress keyup blur",'.txtinput-filter-decimal',function (event) {
        //this.value = this.value.replace(/[^0-9\.]/g,'');
        jQuery(this).val(jQuery(this).val().replace(/[^0-9\.]/g,''));
        if((event.which == 8) || (event.keyCode >= 35 && event.keyCode <= 39) || (event.keyCode == 65 && event.ctrlKey == true)){
            return true;
        }
        else if ((event.which != 46 || jQuery(this).val().indexOf('.') != -1) && (event.which < 48 || event.which > 57)) {
            event.preventDefault();
        }

    });

    var urlreg = /^(http(s)?:\/\/)?(www\.)?[a-z0-9]+([\-\.]{1}[a-z0-9]+)*\.[a-z]{2,5}(:[0-9]{1,5})?(\/.*)?$/;

    var emailreg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;

    jQuery('.form-validation').on('submit', function () {
        var errors = false;
        var top;
        var indexActiveTab;
        
        jQuery('.txtinput-required,.req-custom:visible,.tabs-region:visible .req-branch').each(function () {
            if (jQuery(this).val().trim().length < 1) {
                jQuery(this).addClass('error-required');
                if (jQuery(this).hasClass('txtinput-normal-with-icon'))
                {
                    jQuery(this).parent().find('.txtinput-normal-with-icon-content-icon').addClass('error-icon-required');
                }
                if (errors == false) {
                    top = jQuery(this);
                    indexActiveTab = jQuery(this).parents('.tab-content').index();
                }
                errors = true;
            }
            else {
                jQuery(this).removeClass('error-required');
                jQuery(this).parent().find('.txtinput-normal-with-icon-content-icon').removeClass('error-icon-required');
            }
        });

        jQuery('.txtinput-url').each(function () {
            if (jQuery(this).val().trim().length > 0) {
                if (urlreg.test(jQuery(this).val().trim()) == false) {
                    jQuery(this).addClass('error-required');
                    if (!jQuery(this).parent().find('.error-msg-validation').is(':visible')) {
                        jQuery(this).parent().append('<span class="error-msg-validation">الرجاء ادخال رابط صحيح</span>');
                    }
                    if (errors == false) {
                        top = jQuery(this);
                        indexActiveTab = jQuery(this).parents('.tab-content').index();
                    }
                    errors = true;
                }
                else {
                    jQuery(this).removeClass('error-required');
                    jQuery(this).parent().find('.error-msg-validation').remove();
                } 
            }
        });
        
        jQuery('.txtinput-email').each(function () {
            if (jQuery(this).val().trim().length > 0) {
                if (emailreg.test(jQuery(this).val().trim()) == false) {
                    jQuery(this).addClass('error-required');
                    if (!jQuery(this).parent().find('.error-msg-validation').is(':visible')) {
                        jQuery(this).parent().append('<span class="error-msg-validation">الرجاء ادخال بريد الكتروني صحيح</span>');
                    }
                    if (errors == false) {
                        top = jQuery(this);
                        indexActiveTab = jQuery(this).parents('.tab-content').index();
                    }
                    errors = true;
                }
                else {
                    jQuery(this).removeClass('error-required');
                    jQuery(this).parent().find('.error-msg-validation').remove();
                }
            }
        });

        jQuery('.txtinput-minlength').each(function () {
            var txtinput_minlength_val = jQuery(this).attr('data-minlength');
            if (jQuery(this).val().trim().length < txtinput_minlength_val) {
                jQuery(this).addClass('error-required');
                if (!jQuery(this).parent().find('.error-msg-validation').is(':visible')) {
                    jQuery(this).parent().append('<span class="error-msg-validation"> الرجاء ادخال على الاقل ' + txtinput_minlength_val + ' خانات </span>');
                }
                if (errors == false) {
                    top = jQuery(this);
                    indexActiveTab = jQuery(this).parents('.tab-content').index();
                }
                errors = true;
            }
            else {
                jQuery(this).removeClass('error-required');
                jQuery(this).parent().find('.error-msg-validation').remove();
            }
        });

        jQuery('.txtinput-confirm-password').each(function () {
            var confirm_password_val = jQuery(this).val().trim();
            var password_val = jQuery(this).parent().parent().find('.txtinput-password').val().trim();
            //if (jQuery(this).val().trim().length > 0) {
                if (confirm_password_val != password_val)
                {
                    jQuery(this).addClass('error-required');
                    if (!jQuery(this).parent().find('.error-msg-validation').is(':visible')) {
                        jQuery(this).parent().append('<span class="error-msg-validation">كلمة المرور غير متساوية</span>');
                    }
                    if (errors == false) {
                        top = jQuery(this);
                        indexActiveTab = jQuery(this).parents('.tab-content').index();
                    }
                    errors = true;
                }
                else {
                    jQuery(this).removeClass('error-required');
                    jQuery(this).parent().find('.error-msg-validation').remove();
                }
            //}
        });

        jQuery('.dropdown-menu-normal-required').each(function () {
            if (jQuery(this).find('.hidden-dropdown-menu-normal').val().trim().length < 1) {
                jQuery(this).find('.dropdown-menu-normal-value').addClass('error-required');
                if (errors == false) {
                    top = jQuery(this);
                    indexActiveTab = jQuery(this).parents('.tab-content').index();
                }
                errors = true;
            }
            else {
                jQuery(this).find('.dropdown-menu-normal-value').removeClass('error-required');
            }
        });

        //jQuery('.txtinput-question-answers-required').each(function () {
        //    if (jQuery(this).parent().parent().find('.all-vote-question-answers').children().size() < 2)
        //    {
        //        if (errors == false) {
        //            top = jQuery(this);
        //        }
        //        errors = true;
        //        if (!jQuery('.fault-msg-region-question-answer').is(':visible')) {
        //            jQuery(this).parent().after('<div class="confirm-fault-msg-region fault-msg-region confirm-msg-faild margin-bottom-twenty fault-msg-region-question-answer">الرجاء قم باضافة اجابتين على الاقل</div>');
        //            jQuery('.fault-msg-region-question-answer').delay(2500).slideUp(200);
        //        }
        //        else {
        //            jQuery('.fault-msg-region-question-answer').remove();
        //        }
        //    }
        //});

        jQuery('.tab-choese>ul>li').eq(indexActiveTab).click();

        if (errors == true)
        {
            if (top) {
                top = top.offset().top;
                $('html,body').animate({ scrollTop: top - 100 }, 400);
            }
            return false;
        }

    });

});