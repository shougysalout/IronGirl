﻿
jQuery(document).ready(function() {

jQuery('#dropdown-notification-click').click(function () {
        if (!jQuery('#dropdown-menu').is(':visible')) {
            jQuery('#dropdown-menu').slideDown(100);
            jQuery("#dropdown-notification-click").addClass('dropdown-notification-click-open');
        }
        else {
            jQuery('#dropdown-menu').slideUp(100);
            jQuery("#dropdown-notification-click").removeClass('dropdown-notification-click-open');
        }
        return false;
    });

    jQuery(document).on('click','#dropdown-menu>ul>li>a',function () {
        return true;
    });

    tinymce.init({
        selector: ".tinymce",
        language: 'ar',
        directionality: 'rtl',
    });

});


