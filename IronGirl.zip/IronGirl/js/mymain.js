
jQuery(document).ready(function () {

    jQuery('#search-txt').focusin(function () {
        jQuery('#btn-search').css({ "background-color": "#fff" });
    }).focusout(function () {
        jQuery('#btn-search').css({ "background-color": "#1a1e21" });
    });

    jQuery(document).click(function () {
        jQuery('#dropdown-menu').slideUp(100);
        jQuery("#dropdown-notification-click").css({ 'background-position': '0 top' });
    });

    jQuery('#dropdown-notification-click').click(function () {
        if (!jQuery('#dropdown-menu').is(':visible')) {
            jQuery('#dropdown-menu').slideDown(100);
            jQuery("#dropdown-notification-click").css({ 'background-position': '0 bottom' });
        }
        else {
            jQuery('#dropdown-menu').slideUp(100);
            jQuery("#dropdown-notification-click").css({ 'background-position': '0 top' });
        }
        return false;
    });

    jQuery(document).on('click','#dropdown-menu>ul>li>a',function () {
        return true;
    });
        

    jQuery('#main-menu>ul>li>a').mouseover(function () {
        jQuery(this).find('span').addClass('main-menu-span-hover');
        jQuery(this).find('i').addClass('main-menu-i-hover');
        jQuery(this).parent().addClass('main-menu-li-hover');
        jQuery(this).parent().find('.arrow-right-li').show();
    }).mouseleave(function () {
        if (!jQuery(this).hasClass('main-menu-a-select-page')) {
            jQuery(this).find('span').removeClass('main-menu-span-hover');
            jQuery(this).find('i').removeClass('main-menu-i-hover');
            jQuery(this).parent().removeClass('main-menu-li-hover');
            jQuery(this).parent().find('.arrow-right-li').hide();
        }
    });

    jQuery('#main-menu>ul>li>a').click(function () {
        jQuery('#main-menu>ul>li>a').removeClass('main-menu-a-select-page');
        jQuery('#main-menu>ul>li>a').find('span').removeClass('main-menu-span-hover');
        jQuery('#main-menu>ul>li>a').find('i').removeClass('main-menu-i-hover');
        jQuery('#main-menu>ul>li>a').parent().removeClass('main-menu-li-hover');
        jQuery('#main-menu>ul>li>a').parent().find('.arrow-right-li').hide();

        jQuery(this).addClass('main-menu-a-select-page');

        if (jQuery(this).hasClass('main-menu-a-select-page')) {
            jQuery(this).find('span').addClass('main-menu-span-hover');
            jQuery(this).find('i').addClass('main-menu-i-hover');
            jQuery(this).parent().addClass('main-menu-li-hover');
            jQuery(this).parent().find('.arrow-right-li').show();
        }
    });

    jQuery('#controlpanel-home').click();

    jQuery('#controlpanel-menu-images').click();

    jQuery('.open-close-main-menu').click(function () {
        if (jQuery('#rightpanel').css('width') == '260px') {
            jQuery('#main-menu a').css({ 'width': '65px' });
            jQuery('#main-menu a span').css({ 'width': '0px', 'padding': '0px', 'display':'none' });
            jQuery('#rightpanel').animate({ width: "64px" }, 100);
            jQuery('#rightpanel-gray').animate({ width: "65px" }, 100);
            jQuery(this).removeAttr('id').attr('id', 'close-main-menu');
            jQuery('#leftpanel').animate({ marginRight: "65px" }, 100);
        }
        else {
            jQuery('#rightpanel').animate({ width: "260px" }, 200);
            jQuery('#rightpanel-gray').animate({ width: "260px" }, 200);
            jQuery('#main-menu a span').css({ 'width': '100px', 'padding-right': '20px', 'padding-top': '25px', 'display':'block' });
            jQuery('#main-menu a').css({ 'width': '100%' });
            jQuery(this).removeAttr('id');
            jQuery(this).removeAttr('id').attr('id', 'open-main-menu');
            jQuery('#leftpanel').animate({ marginRight: "261px" }, 200);
        }
        return false;
    });

    jQuery("#leftpanel-menu>ul>li>a").click(function () {
        jQuery("#leftpanel-menu>ul>li>a").removeClass("leftpanel-menu-active");
        jQuery(this).addClass("leftpanel-menu-active");
    })

    jQuery('.statistics-num-region').mouseover(function () {
        jQuery(this).addClass('statistics-num-region-hover');
        jQuery(this).find('.statistics-num-name').addClass('statistics-num-name-hover');
    }).mouseleave(function () {
        jQuery(this).removeClass('statistics-num-region-hover');
        jQuery(this).find('.statistics-num-name').removeClass('statistics-num-name-hover');
    });

    jQuery(document).click(function () {
        jQuery('.application-menu-dropdown-list').slideUp(100);
        jQuery('.application-menu-dropdown').css({ 'background-position': '14px top', 'border-bottom-right-radius': '20px', 'border-bottom-left-radius': '20px' });
    });

    jQuery('.application-menu-dropdown').click(function (e) {
        if (!jQuery(this).parent().find('.application-menu-dropdown-list').is(':visible')) {
            jQuery(this).parent().find('.application-menu-dropdown-list').slideDown(100);
            jQuery(this).css({ 'background-position': '14px bottom', 'border-bottom-right-radius': '0', 'border-bottom-left-radius': '0' });
        }
        else {
            jQuery(this).parent().find('.application-menu-dropdown-list').slideUp(100);
            jQuery(this).css({ 'background-position': '14px top', 'border-bottom-right-radius': '20px', 'border-bottom-left-radius': '20px' });
        }
        return false;
    });

    jQuery('.application-menu-dropdown-region>.application-menu-dropdown-list a').click(function () {
        jQuery(this).parents().eq(3).find('.application-menu-value').text(jQuery(this).text());
        jQuery(this).parents().eq(2).find('.hidden-application-menu-dropdown').val(jQuery(this).text());
        jQuery(this).parents().eq(2).find('.hidden-application-menu-dropdown').attr('data-process', jQuery(this).attr('data-process'));
    });

    jQuery(document).on('click', '.checkbox-style', function () {

        if (jQuery(this).parents().eq(2).hasClass('header-table-region')) {
            if (!jQuery(this).hasClass('checkbox-checked')) {
                jQuery(this).addClass('checkbox-checked');
                jQuery(this).parents().eq(3).find('.content-table-area').find('.content-table-region>ul>li').find('.checkbox-style').addClass('checkbox-checked');
                jQuery(this).parents().eq(3).find('.content-table-area').find('.content-table-region>ul>li').find('.hidden-checkbox-val').val('true');

            } else {
                jQuery(this).removeClass('checkbox-checked');
                jQuery(this).parents().eq(3).find('.content-table-area').find('.content-table-region>ul>li').find('.checkbox-style').removeClass('checkbox-checked');
                jQuery(this).parents().eq(3).find('.content-table-area').find('.content-table-region>ul>li').find('.hidden-checkbox-val').val('');
            }
        }
        else {
            
            if (!jQuery(this).hasClass('checkbox-checked')) {
                jQuery(this).addClass('checkbox-checked');
                jQuery(this).parent().find('.hidden-checkbox-val').val('true');
                if (!jQuery(this).parents().eq(2).hasClass('content-table-region-nested')) {
                    jQuery(this).parents().eq(2).nextAll().find('.checkbox-style').addClass('checkbox-checked');
                    jQuery(this).parents().eq(2).nextAll().find('.hidden-checkbox-val').val('true');
                }
                
                var all_content_table_region = 0;
                jQuery(this).parents().eq(5).find('.content-table-region').find('.checkbox-style').each(function () {
                    if (jQuery(this).hasClass('checkbox-checked')) {
                        all_content_table_region++;
                    }
                });
                if (all_content_table_region == jQuery(this).parents().eq(5).find('.content-table-region').size()) {
                    jQuery('.checkbox-checkall,#checkall').addClass('checkbox-checked');
                }
            }
            else {
                jQuery(this).removeClass('checkbox-checked');
                jQuery(this).parent().find('.hidden-checkbox-val').val('');
                if (!jQuery(this).parents().eq(2).hasClass('content-table-region-nested')) {
                    jQuery(this).parents().eq(2).nextAll().find('.checkbox-style').removeClass('checkbox-checked');
                    jQuery(this).parents().eq(2).nextAll().find('.hidden-checkbox-val').val('');
                }
                var flag = jQuery(this).parents().eq(3).find('.content-table-region-nested').size();
                jQuery(this).parents().eq(3).find('.content-table-region-nested').find('.checkbox-style').each(function () {
                    if (!jQuery(this).hasClass('checkbox-checked')) {
                        --flag;
                    }
                });
                if (flag < jQuery(this).parents().eq(3).find('.content-table-region-nested').size()) {
                    jQuery(this).parents().eq(3).find('.content-table-region').first().find('.checkbox-style').removeClass('checkbox-checked');
                    jQuery(this).parents().eq(3).find('.content-table-region').first().find('.hidden-checkbox-val').val('');
                }

                var all_content_table_region = jQuery(this).parents().eq(5).find('.content-table-region').size();
                jQuery(this).parents().eq(5).find('.content-table-region').find('.checkbox-style').each(function () {
                    if (!jQuery(this).hasClass('checkbox-checked')) {
                        all_content_table_region--;
                    }
                });
                if (all_content_table_region < jQuery(this).parents().eq(5).find('.content-table-region').size()) {
                    jQuery('.checkbox-checkall,#checkall').removeClass('checkbox-checked');
                }
            }
        }

    });

    jQuery('.btn-addnewtxtinput').click(function () {
        if (jQuery(this).parent().find('.txtinput-normal-with-btn-addnewtxtinput').val() != "") {
            jQuery(this).parent().parent().find('.all-vote-question-answers').append(
                '<div class="txtinput-normal-content row-txtinput-normal-content">'
                    + '<input type="text" placeholder="خيار السؤال" class="txtinput-normal txtinput-normal-width-large txtinput-question-answers-required transition-move txtinput-normal-with-btn-addnewtxtinput float-right" />'
                     +'<span class="btn-adddeletenewtxtinput btn-deletenewtxtinput float-right"></span>'
                + '</div>'
             );
            jQuery(this).parent().find('.txtinput-normal-with-btn-addnewtxtinput').val('');
        }
    });

    jQuery(document).on('click', '.btn-deletenewtxtinput', function () {
        jQuery(this).parent().remove();
    });
    
    jQuery(document).on('click', '.on-status-click', function () {
        if (jQuery(this).parent().hasClass('on-off-status-on') && !jQuery(this).parent().hasClass('on-off-status-all') && !jQuery(this).parent().hasClass('on-off-status-selectall')) {
            jQuery(this).parent().removeClass('on-off-status-on');
            jQuery(this).parent().addClass('on-off-status-off');
            jQuery(this).removeClass('on-status-click');
            jQuery(this).addClass('on-off-status-span-true-false on-status-click-false');
            jQuery(this).next().addClass('on-status-click');
            jQuery(this).next().removeClass('on-off-status-span-true-false on-status-click-true');
            jQuery(this).parent().parent().find('.hidden-on-off-status').val('2');
        }

        else if (jQuery(this).parent().hasClass('on-off-status-off') && !jQuery(this).parent().hasClass('on-off-status-all') && !jQuery(this).parent().hasClass('on-off-status-selectall'))
        {
            jQuery(this).parent().removeClass('on-off-status-off');
            jQuery(this).parent().addClass('on-off-status-on');
            jQuery(this).removeClass('on-status-click');
            jQuery(this).addClass('on-off-status-span-true-false on-status-click-true');
            jQuery(this).prev().addClass('on-status-click');
            jQuery(this).prev().removeClass('on-off-status-span-true-false on-status-click-false');
            jQuery(this).parent().parent().find('.hidden-on-off-status').val('1');
        }

        else if (jQuery(this).parent().hasClass('on-off-status-on') && jQuery(this).parent().hasClass('on-off-status-all')) {
            jQuery(this).parents().eq(4).find('.on-off-status').removeClass('on-off-status-on');
            jQuery(this).parents().eq(4).find('.on-off-status').addClass('on-off-status-off');
            jQuery(this).parents().eq(4).find('.on-status-click').removeClass('on-status-click');
            jQuery(this).parents().eq(4).find('.on-off-status-span-first').addClass('on-off-status-span-true-false on-status-click-false');
            jQuery(this).parents().eq(4).find('.on-off-status-span-first').next().addClass('on-status-click');
            jQuery(this).parents().eq(4).find('.on-off-status-span-first').next().removeClass('on-off-status-span-true-false on-status-click-true');
            jQuery(this).parents().eq(4).find('.hidden-on-off-status').val('2');
        }

        else if (jQuery(this).parent().hasClass('on-off-status-off') && jQuery(this).parent().hasClass('on-off-status-all'))
        {
            jQuery(this).parents().eq(4).find('.on-off-status').removeClass('on-off-status-off');
            jQuery(this).parents().eq(4).find('.on-off-status').addClass('on-off-status-on');
            jQuery(this).parents().eq(4).find('.on-status-click').removeClass('on-status-click');
            jQuery(this).parents().eq(4).find('.on-off-status-span-first').addClass('on-status-click');
            jQuery(this).parents().eq(4).find('.on-off-status-span-first').next().addClass('on-off-status-span-true-false on-status-click-true');
            jQuery(this).parents().eq(4).find('.hidden-on-off-status').val('1');
        }

       else if (jQuery(this).parent().hasClass('on-off-status-on') && jQuery(this).parent().hasClass('on-off-status-selectall')) {
            jQuery('.on-off-status').removeClass('on-off-status-on');
            jQuery('.on-off-status').addClass('on-off-status-off');
            jQuery('.on-status-click').removeClass('on-status-click');
            jQuery('.on-off-status-span-first').addClass('on-off-status-span-true-false on-status-click-false');
            jQuery('.on-off-status-span-first').next().addClass('on-status-click');
            jQuery('.on-off-status-span-first').next().removeClass('on-off-status-span-true-false on-status-click-true');
            jQuery('.hidden-on-off-status').val('2');
        }

        else if (jQuery(this).parent().hasClass('on-off-status-off') && jQuery(this).parent().hasClass('on-off-status-selectall')) {
            jQuery('.on-off-status').removeClass('on-off-status-off');
            jQuery('.on-off-status').addClass('on-off-status-on');
            jQuery('.on-status-click').removeClass('on-status-click');
            jQuery('.on-off-status-span-first').addClass('on-status-click');
            jQuery('.on-off-status-span-first').next().addClass('on-off-status-span-true-false on-status-click-true');
            jQuery('.hidden-on-off-status').val('1');
        }

    });

    jQuery(document).on('click', '.on-off-status-event', function () {
        if (jQuery(this).hasClass('on-off-status-off')) {
            jQuery('.btn-upload-img-progress-view').show(0);
            jQuery('.lbl-txtinput-ads').text('رابط الاعلان');
        }
        else {
            jQuery('.btn-upload-img-progress-view').hide(0);
            jQuery('.lbl-txtinput-ads').text('رابط الفعالية');
        }
    });

    jQuery(document).on('click','.dropdown-menu-normal-value',function () {
        jQuery(document).click();
        if (!jQuery(this).parent().find('.dropdown-menu-normal-list').is(':visible')) {
            jQuery(this).parent().find('.dropdown-menu-normal-list').slideDown(200);
            jQuery(this).addClass('dropdown-menu-normal-value-open');
            //jQuery(this).css({ 'background-position': 'left 20px bottom 0px' });
        }
        else {
            jQuery(this).parent().find('.dropdown-menu-normal-list').slideUp(100);
            jQuery(this).removeClass('dropdown-menu-normal-value-open');
            //jQuery(this).css({ 'background-position': 'left 20px top 0px' });
        }
        return false;
    });

    jQuery(document).click(function () {
        jQuery('.dropdown-menu-normal-list').slideUp();
        jQuery('.dropdown-menu-normal-value').removeClass('dropdown-menu-normal-value-open');
        //jQuery('.dropdown-menu-normal-value').css({ 'background-position': 'left 20px top 0px' });
    });

    //jQuery('.dropdown-menu-normal-list>ul>li>a').click(function () {
    //    jQuery(this).parent().parent().parent().parent().find('.dropdown-menu-normal-value').text(jQuery(this).text());
    //    jQuery(this).parent().parent().parent().parent().find('.hidden-dropdown-menu-normal').val(jQuery(this).text());
    //});

    /*jQuery('.txtinput-normal-with-icon-content').mouseover(function () {
        jQuery(this).find('.txtinput-normal-with-icon-content-icon').css({ 'background-color': '#bbbbbb','color':'#fff' });
        jQuery(this).find('.txtinput-normal-with-icon').css({ 'border-color': '#bbbbbb' });
    }).mouseleave(function () {
        if (jQuery(this).parent().find('.txtinput-normal-with-icon').is(":focus")) {
            jQuery(this).parent().find('.txtinput-normal-with-icon-content-icon').css({ 'background-color': '#47c2b6','color':'#fff' });
            jQuery(this).parent().find('.txtinput-normal-with-icon').css({ 'border-color': '#47c2b6' });
        }
        else {
            jQuery(this).parent().find('.txtinput-normal-with-icon-content-icon').css({ 'background-color': '#dddddd', 'color': '#bbbbbb' });
            jQuery(this).parent().find('.txtinput-normal-with-icon').css({ 'border-color': '#dddddd' });
        }
    });

    jQuery('.txtinput-normal-with-icon').focusin(function () {
        jQuery(this).parent().find('.txtinput-normal-with-icon-content-icon').css({ 'background-color': '#47c2b6', 'color': '#fff' });
        jQuery(this).css({ 'border-color': '#47c2b6' });
    }).focusout(function () {
        jQuery(this).parent().find('.txtinput-normal-with-icon-content-icon').css({ 'background-color': '#dddddd','color':'#bbbbbb' });
        jQuery(this).css({ 'border-color': '#dddddd' });
    });
    
    jQuery('.txtinput-with-icon-i').click(function () {
        jQuery(this).parent().find('.txtinput-normal-with-icon').focus();
    });*/

    jQuery(document).on('click','.select-switch-text',function () {
        jQuery(this).parent().find('.select-switch-text ').removeClass('select-switch-text-active');
        jQuery(this).addClass('select-switch-text-active');
        jQuery(this).parent().find('.hidden-select-switch-text').val(jQuery(this).text());
    });

    

    tinymce.init({
        selector: ".tinymce",
        language: 'ar',
        directionality: 'rtl',
    });

    jQuery(document).on('mouseover', '.media-file-added-region', function () {
        jQuery(this).find('.delete-media-file-from-list').show();
    }).on('mouseleave', '.media-file-added-region', function () {
        jQuery(this).find('.delete-media-file-from-list').hide();
    });

    jQuery('.btn-addcategory-box-left-column').click(function () {
        if (!jQuery(this).parent().parent().find('.add-category-left-column-region').is(':visible')) {
            jQuery(this).parent().parent().find('.add-category-left-column-region').slideDown();
            $('body').scrollTo('.add-category-left-column-region', { duration: 'slow' });
        }
        else {
            jQuery(this).parent().parent().find('.add-category-left-column-region').slideUp();
        }
    });

    //jQuery(document).on('click','.btn-box-left-column-add-tag', function () {
    //    if (jQuery(this).parent().find('.txtinput-small-add-tag').val() != "") {
    //        jQuery(this).parent().parent().find('.tags-added-by-user').append('<a><span>x</span>' + jQuery(this).parent().find('.txtinput-small-add-tag').val() + '</a>');
    //        jQuery(this).parent().find('.txtinput-small-add-tag').val('');
    //    }
    //});

    //jQuery(document).on('keydown', function (e) {
    //    if (e.keyCode == "13") {
    //        jQuery('.btn-box-left-column-add-tag').click();
    //    }
    //});

    //jQuery(document).on('click','.tags-added-by-user>a>span', function () {
    //    jQuery(this).parent().remove();
    //});

    /*jQuery(document).click(function () {
        jQuery('.tags-added-earlier-content').slideUp();
        jQuery('.tags-added-earlier-menu').css({ 'background-position': '14px top', 'border-bottom-right-radius': '20px', 'border-bottom-left-radius': '20px' });
    });*/

    jQuery('.tags-added-earlier-menu').click(function () {
        if (!jQuery(this).parent().find('.tags-added-earlier-content').is(':visible')) {
            jQuery(this).parent().find('.tags-added-earlier-content').slideDown();
            jQuery(this).css({ 'background-position': '14px bottom', 'border-bottom-right-radius': '0', 'border-bottom-left-radius': '0' });
        }
        else {
            jQuery(this).parent().find('.tags-added-earlier-content').slideUp();
            jQuery(this).css({ 'background-position': '14px top', 'border-bottom-right-radius': '20px', 'border-bottom-left-radius': '20px' });
        }
        return false;
    });

    jQuery('.checkbox-tag').click(function () {
        if (!jQuery(this).hasClass('checkbox-tag-checked')) {
            jQuery(this).addClass('checkbox-tag-checked');
            jQuery(this).parent().css({ 'background-color': '#47c2b6', 'color': '#fff', 'border-color': '#47c2b6' });
            jQuery(this).parent().find('.hidden-checkbox-tag-val').val('true');
        }
        else  {
            jQuery(this).removeClass('checkbox-tag-checked');
            jQuery(this).parent().css({ 'background-color': '#eeeeee', 'color': '#666666', 'border-color': '#dddddd' });
            jQuery(this).parent().find('.hidden-checkbox-tag-val').val('');
        }
        return false;
    });

    jQuery('.btn-modal-choose-img').click(function () {
        jQuery('.modal-input-choose-file').click();
    });

    jQuery(document).on('click','.item-file-modal-footer-region',function () {
        jQuery(this).addClass('item-file-modal-footer-region-selected');
    });

    jQuery(document).on('click','.btn-delete-modal-files',function () {
        jQuery(this).parent().parent().parent().find('.item-file-modal-footer-region-selected').remove();
    });

    jQuery('.selected-items-content').append(
        '<div class="item-file-modal-footer-region">'
            + '<div class="item-file-modal-footer-content">'
                + '<div class="item-file-modal-footer">'
                    + '<img alt="itemname" src="otherimages/item-footer-modal-img1.png">'
                + '</div>'
            + '</div>'
        + '</div>'
    );

    /*jQuery('.uploaded-img-region').mouseover(function () {
        jQuery(this).find('.selected-hover-region').css({ 'background-position': 'left bottom' }).show();
    }).mouseleave(function () {
        jQuery(this).find('.selected-hover-region').hide();
    });*/

    

    //jQuery(document).on('click','.selected-hover-region-unselect', function () {
    //    jQuery(this).parent().find('.selected-hover-region').removeClass('selected-hover-region-delete selected-hover-region-unselect').hide();
    //    jQuery(this).parent().css({ 'border-color': '#fbfbfb' });
    //});

    //jQuery(document).on('click','.selected-hover-region-delete', function () {
    //    jQuery(this).parent().parent().remove();
    //});

    //jQuery(document).on('mouseover','.uploaded-img-region', function () {
    //    if (jQuery(this).find('.selected-hover-region').hasClass('selected-hover-region-select') || jQuery(this).find('.selected-hover-region').hasClass('selected-hover-region-unselect')) {
    //        jQuery(this).find('.selected-hover-region').removeClass('selected-hover-region-select').addClass('selected-hover-region-unselect');
    //    }
    //    //else {
    //    //    jQuery(this).find('.selected-hover-region').css({ 'background-position': 'left bottom' }).addClass('selected-hover-region-delete').show();
    //    //}
    //}).on('mouseleave','.uploaded-img-region', function () {
    //    if (jQuery(this).find('.selected-hover-region').hasClass('selected-hover-region-unselect') || jQuery(this).find('.selected-hover-region').hasClass('selected-hover-region-select')) {
    //        jQuery(this).find('.selected-hover-region').removeClass('selected-hover-region-unselect').addClass('selected-hover-region-select');
    //    }
    //    //else {
    //    //    jQuery(this).find('.selected-hover-region').removeClass('selected-hover-region-delete').hide();
    //    //}
    //});

    jQuery(document).on('mouseover', '.uploaded-img-region', function () {
        if (!jQuery(this).find('.selected-hover-region').hasClass('selected-hover-region-select') && !jQuery(this).find('.selected-hover-region').hasClass('selectedclick')) {
            jQuery(this).find('.selected-hover-region').addClass('selected-hover-region-select').show();
        }
        if (jQuery(this).find('.selected-hover-region').hasClass('selected-hover-region-select') && !jQuery(this).find('.selected-hover-region').hasClass('selectedclick')) {
            jQuery(this).find('.selected-hover-region').show();
        }
        if (jQuery(this).find('.selected-hover-region').hasClass('selected-hover-region-select') && jQuery(this).find('.selected-hover-region').hasClass('selectedclick')) {
            jQuery(this).find('.selected-hover-region').removeClass('selected-hover-region-select').addClass('selected-hover-region-unselect').show();
        }
    }).on('mouseleave', '.uploaded-img-region', function () {
        if (!jQuery(this).find('.selected-hover-region').hasClass('selectedclick')) {
            jQuery(this).find('.selected-hover-region').hide();
        }
        if (jQuery(this).find('.selected-hover-region').hasClass('selected-hover-region-unselect') && jQuery(this).find('.selected-hover-region').hasClass('selectedclick')) {
            jQuery(this).find('.selected-hover-region').removeClass('selected-hover-region-unselect').addClass('selected-hover-region-select').show();
        }
    });

    jQuery(document).on('click', '.uploaded-img-region', function () {
        if (!jQuery(this).find('.selected-hover-region').hasClass('selectedclick')) {
            jQuery(this).find('.selected-hover-region').addClass('selected-hover-region-select').show();
            jQuery(this).css({ 'border-color': '#47c2b6' });
            jQuery(this).find('.selected-hover-region').addClass('selectedclick');
        }
        else {
            jQuery(this).find('.selected-hover-region').removeClass('selected-hover-region-select');
            jQuery(this).find('.selected-hover-region').removeClass('selected-hover-region-unselect');
            jQuery(this).css({ 'border-color': '#fbfbfb' });
            jQuery(this).find('.selected-hover-region').removeClass('selectedclick');
        }
    });

    $(".fancybox-manual-add-media").click(function () {
        $.fancybox.open({
            href: 'modal-add-media-images.html',
            type: 'iframe',
            padding: 0,
            closeBtn: false,
            closeClick: true,
            width: screen.width,
            height: screen.height
        });
    });

    jQuery('.close-modal-add-media').click(function () {
        parent.$.fancybox.close();
    });

    jQuery('.btn-edit-date-time-publish-post').click(function () {
        if (jQuery(this).parent().find('.date-time-publish-post-date-and-text-content').is(':visible'))
        {
            jQuery(this).parent().find('.date-time-publish-post-date-and-text-content').hide();
            jQuery(this).parent().find('.txtinput-calender-published-post-content').slideDown(400);
            jQuery(this).css({'background-position':'left bottom'});
        }
        else if (jQuery(this).parent().find('.txtinput-calender-published-post-content').is(':visible')) {
            jQuery(this).parent().find('.txtinput-calender-published-post-content').hide();
            jQuery(this).parent().find('.date-time-publish-post-date-and-text-content').slideDown(400);
            jQuery(this).css({ 'background-position': 'left top' });
        }
        return false;
    });

    jQuery('.btn-spinner-next-prev').click(function () {
        var txtinput_normal_number_spinner = parseInt(jQuery(this).parent().parent().find('.txtinput-normal').val());
        var txtinput_sliderno_val = parseInt(jQuery(this).parent().parent().find('.txtinput-normal').attr('data-sliderno'));
        //jQuery(this).parent().parent().find('.txtinput-normal').addClass('txtinput-normal-number');
        if (jQuery(this).parent().parent().find('.txtinput-normal').val() == "") {
            txtinput_normal_number_spinner = 0; 
        }
        if (jQuery(this).hasClass('btn-spinner-next-prev-up')) {
            jQuery(this).parent().parent().find('.txtinput-normal').val(txtinput_normal_number_spinner + 1);
        }
        if (jQuery(this).hasClass('btn-spinner-next-prev-down') && (jQuery(this).parent().parent().find('.txtinput-normal').val() >= 1)) {
            var new_val = txtinput_normal_number_spinner - 1;
            if (new_val < 1) {
                jQuery(this).parent().parent().find('.txtinput-normal').val('1');
            }
            else {
                jQuery(this).parent().parent().find('.txtinput-normal').val(new_val);
            }
        }
        jQuery('.txtinput-sliderno').keyup();
    });

    jQuery(document).on('keyup', '.txtinput-sliderno', function () {
        var txtinput_sliderno_val = jQuery(this).attr('data-sliderno');
        var txtinput_sliderno_user_val = jQuery(this).val().trim();
        if (parseInt(txtinput_sliderno_user_val) > parseInt(txtinput_sliderno_val)) {
            jQuery(this).val(txtinput_sliderno_val);
        }
        else {
            jQuery(this).val(txtinput_sliderno_user_val);
        }
        if (txtinput_sliderno_user_val == '0')
        {
            jQuery(this).val('1');
        }
    });

    jQuery('.txtinput-normal-number-images-slider').keyup(function () {
        if (jQuery(this).val() == "") {
            jQuery(this).removeClass('txtinput-normal-number');
        }
        else
        {
            jQuery(this).addClass('txtinput-normal-number');
        }

    });

    //jQuery('.btn-add-group-txtinputs-organizers,.btn-add-group-txtinputs-sponsors').click(function () {
    //    var counterinput = 0;
    //    jQuery(this).parent().parent().find('.all-info-after-added-area').append(
    //        '<div class="all-info-after-added-region clearfix txtinputs-all-speakers-region box-sizing">'
    //            +'<div class="txtinput-sponsor-region padding-left-twenty float-right margin-bottom-twenty box-sizing">'
    //                +'<input type="text" class="txtinput-normal txtinput-normal-width-halfrow transition-move" placeholder="اسم الراعي">'
    //            +'</div><!--txtinput sponsor region-->'
    //            +'<div class="txtinput-sponsor-region padding-left-twenty float-right margin-bottom-twenty box-sizing">'
    //                +'<input type="text" class="txtinput-normal txtbox-filter-number txtinput-normal-width-halfrow transition-move" placeholder="رقم الجوال">'
    //            +'</div><!--txtinput sponsor region-->'
    //            +'<div class="txtinput-sponsor-region padding-left-twenty float-right margin-bottom-twenty box-sizing">'
    //                +'<input type="text" class="txtinput-normal txtinput-normal-width-halfrow transition-move" placeholder="حساب الفيس بوك">'
    //            +'</div><!--txtinput sponsor region-->'
    //            +'<div class="txtinput-sponsor-region padding-left-twenty float-right margin-bottom-twenty box-sizing">'
    //                +'<input type="text" class="txtinput-normal txtinput-normal-width-halfrow transition-move" placeholder="حساب تويتر">'
    //            +'</div><!--txtinput sponsor region-->'
    //            + '<div class="btn-add-group-txtinputs btn-add-group-txtinputs-leftbottom float-right margin-bottom-twenty btn-delete-group-txtinputs-organizers">'
    //                +'<i class="fa fa-minus"></i>'
    //            +'</div>'
    //        +'</div>'
    //    );
    //    jQuery(this).parent().find('.txtinput-normal').val('');
    //});

    //jQuery('.btn-add-group-txtinputs-speakers').click(function () {
    //    var counterinput = 0;
    //    jQuery(this).parent().parent().find('.all-info-after-added-area').append(
    //        '<div class="all-info-after-added-region clearfix txtinputs-all-speakers-region box-sizing">'
                
    //                +'<div class="txtinput-sponsor-region padding-left-twenty float-right margin-bottom-twenty box-sizing">'
    //                    +'<input type="text" class="txtinput-normal txtinput-normal-width-halfrow transition-move" placeholder="اسم المتحدث">'
    //                +'</div><!--txtinput sponsor region-->'
    //                +'<div class="txtinput-sponsor-region padding-left-twenty float-right margin-bottom-twenty box-sizing">'
    //                    +'<input type="text" class="txtinput-normal txtbox-filter-number txtinput-normal-width-halfrow transition-move" placeholder="رقم الجوال">'
    //                +'</div><!--txtinput sponsor region-->'
    //                +'<div class="txtinput-sponsor-region padding-left-twenty float-right margin-bottom-twenty box-sizing">'
    //                    +'<input type="text" class="txtinput-normal txtinput-normal-width-halfrow transition-move" placeholder="حساب الفيس بوك">'
    //                +'</div><!--txtinput sponsor region-->'
    //                +'<div class="txtinput-sponsor-region padding-left-twenty float-right margin-bottom-twenty box-sizing">'
    //                    +'<input type="text" class="txtinput-normal txtinput-normal-width-halfrow transition-move" placeholder="حساب تويتر">'
    //                +'</div><!--txtinput sponsor region-->'
    //                +'<div class="txtinput-sponsor-region2 margin-left-twenty margin-bottom-twenty box-sizing">'
    //                    +'<input type="text" class="txtinput-normal txtinput-normal-width-full transition-move" placeholder="يتحدث عن">'
    //                +'</div><!--txtinput sponsor region-->'
    //                +'<div class="btn-add-group-txtinputs btn-add-group-txtinputs-leftbottom btn-add-group-txtinputs-speakers float-right margin-bottom-twenty">'
    //                    +'<i class="fa fa-plus"></i>'
    //                +'</div><!--btn add group txtinputs-->'
                
    //            + '<div class="btn-add-group-txtinputs btn-add-group-txtinputs-leftbottom float-right margin-bottom-twenty btn-delete-group-txtinputs-organizers">'
    //                + '<i class="fa fa-minus"></i>'
    //            + '</div>'
    //        + '</div>'
    //    );
    //    jQuery(this).parent().find('.txtinput-normal').val('');
    //});

    jQuery(document).on('click', '.btn-delete-group-txtinputs-organizers,.btn-delete-group-txtinputs-speakers', function () {
        jQuery(this).parent().remove();
    });

    jQuery(document).on('keydown', '.txtbox-filter-number', function (event) {
        // Allow: backspace, delete, tab, escape, enter and .
        if ($.inArray(event.keyCode, [46, 8, 9, 27, 13, 190]) !== -1 ||
            // Allow: Ctrl+A
            (event.keyCode == 65 && event.ctrlKey === true) ||
            // Allow: home, end, left, right
            (event.keyCode >= 35 && event.keyCode <= 39)) {
            // let it happen, don't do anything
            return;
        }
        else {
            // Ensure that it is a number and stop the keypress
            if (event.shiftKey || (event.keyCode < 48 || event.keyCode > 57) && (event.keyCode < 96 || event.keyCode > 105)) {
                event.preventDefault();
            }
        }
    });

    jQuery('.upload-image-event-region').click(function () {
        jQuery(this).parent().find('.hidden-upload-image-event-file').click();
    });

    //jQuery(document).on('click', '.upload-image-ads-view-region-hover', function () {
    //    jQuery(this).parent().find('img').attr({'src':'','alt':''});
    //});

    jQuery('.btn-image-view-user-profile-content').click(function () {
        jQuery(this).parent().find('.hidden-image-view-user-profile').click();
    });

    jQuery('.btn-upload-click').click(function () {
        jQuery(this).parent().find('input[type=file]').click();
    });

    jQuery(document).on('keyup', '.time-txtinput-small-hours', function () {
        if (jQuery(this).val().trim() > 12 || jQuery(this).val().trim() < 1) {
            jQuery(this).val('01');
        }
    });

    jQuery(document).on('keyup', '.time-txtinput-small-minutes', function () {
        if (jQuery(this).val().trim() > 59) {
            jQuery(this).val('00');
        }
    });

    jQuery(document).on('click', '.time-select-updown-up', function () {
        var input_hours_minutes_focus = jQuery(this).parent().parent().find('.time-txtinput-small-focus');

        if (input_hours_minutes_focus.hasClass('time-txtinput-small-hours')) {
            var hours_old = input_hours_minutes_focus.val();
            var hours_new = parseInt(hours_old) + 1;
            if (hours_new < 10) {
                input_hours_minutes_focus.val('0' + hours_new);
            }
            else {
                input_hours_minutes_focus.val(hours_new);
            }
            jQuery(this).parent().parent().find('.time-txtinput-small-hours').keyup();
        }

        if (input_hours_minutes_focus.hasClass('time-txtinput-small-minutes')) {

            var minutes_old = input_hours_minutes_focus.val();
            var minutes_new = parseInt(minutes_old) + 1;

            if (minutes_new < 10) {
                input_hours_minutes_focus.val('0' + minutes_new);
            }
            else {
                input_hours_minutes_focus.val(minutes_new);
            }
            if (minutes_new > 59) {
                input_hours_minutes_focus.val('00');
                var input_hours = jQuery(this).parent().parent().find('.time-txtinput-small-hours');
                var input_hours_val = input_hours.val();
                var input_hours_val_new = parseInt(input_hours_val) + 1;
                if (input_hours_val_new < 10) {
                    input_hours.val('0' + input_hours_val_new);
                }
                else {
                    input_hours.val(input_hours_val_new);
                }
                jQuery(this).parent().parent().find('.time-txtinput-small-hours').keyup();
            }
        }
    });

    jQuery(document).on('click', '.time-select-updown-down', function () {
        var input_hours_minutes_focus = jQuery(this).parent().parent().find('.time-txtinput-small-focus');

        if (input_hours_minutes_focus.hasClass('time-txtinput-small-hours')) {
            var hours_old = input_hours_minutes_focus.val();
            var hours_new = parseInt(hours_old) - 1;
            if (hours_new < 10) {
                input_hours_minutes_focus.val('0' + hours_new);
            }
            else {
                input_hours_minutes_focus.val(hours_new);
            }
            if (hours_new < 1) {
                input_hours_minutes_focus.val('12');
            }
            
            jQuery(this).parent().parent().find('.time-txtinput-small-hours').keyup();
        }


        if (input_hours_minutes_focus.hasClass('time-txtinput-small-minutes')) {

            var minutes_old = input_hours_minutes_focus.val();
            var minutes_new = parseInt(minutes_old) - 1;
            
            if (minutes_new < 10) {
                input_hours_minutes_focus.val('0' + minutes_new);
            }
            else {
                input_hours_minutes_focus.val(minutes_new);
            }
            if (minutes_new < 0) {
                input_hours_minutes_focus.val('59');

                var input_hours = jQuery(this).parent().parent().find('.time-txtinput-small-hours');
                var input_hours_val = input_hours.val();
                var input_hours_val_new = parseInt(input_hours_val) - 1;
                if (input_hours_val_new < 10) {
                    input_hours.val('0' + input_hours_val_new);
                }
                else {
                    input_hours.val(input_hours_val_new);
                    
                }
                if (input_hours_val_new < 1) {
                    input_hours.val('12');
                }
                jQuery(this).parent().parent().find('.time-txtinput-small-hours').keyup();
            }

        }
    });

    function time() {
        var currentTime = new Date();
        var hours = currentTime.getHours();
        var minutes = currentTime.getMinutes();

        var hourview = 0;
        if (hours >= 12) {
            hourview = hours - 12;
            jQuery('.select-timetype-text').removeClass('select-switch-text-active');
            jQuery('.select-timetype-text-pm').addClass('select-switch-text-active');
        }
        if (hours < 12) {
            hourview = hours;
            jQuery('.select-timetype-text').removeClass('select-switch-text-active');
            jQuery('.select-timetype-text-am').addClass('select-switch-text-active');
        }

        if (hourview < 10) {
            hourview = '0' + hourview;
        }

        var minutesview;
        if (minutes < 10) {
            minutesview = '0' + minutes;
        }
        else {
            minutesview = minutes;
        }

        jQuery('.time-txtinput-small-hours').val(hourview);
        jQuery('.time-txtinput-small-minutes').val(minutesview);
    }

    time();

    jQuery(document).on('click', '.time-txtinput-small', function () {
        jQuery(this).parent().find('.time-txtinput-small').removeClass('time-txtinput-small-focus');
        jQuery(this).addClass('time-txtinput-small-focus');
    });

    jQuery(document).on('click', '.btn-upload-special-img', function () {
        jQuery(this).parent().find('.hidden-special-img').click();
    });

    //jQuery(document).on('click', '.btn-delete-post', function () {
    //    var thisdeleteparent = jQuery(this).parents().eq(5);
    //    var thisdelete = jQuery(this).parents().eq(6);
    //    var thisdeletemedia = jQuery(this).parents().eq(5);

    //    if (confirm("هل تريد الحذف بالتأكيد")) {
    //        if (jQuery(this).hasClass('btn-delete-post-addmedia')) {
    //            thisdeletemedia.slideUp(200);
    //            setTimeout(function () {
    //                thisdeletemedia.remove();
    //            }, 400);
    //        }
    //        else {
    //            if (thisdeleteparent.hasClass('content-table-region-nested')) {
    //                thisdeleteparent.slideUp(200);
    //                setTimeout(function () {
    //                    thisdeleteparent.remove();
    //                }, 400);
    //            }
    //            else {
    //                thisdelete.slideUp(200);
    //                setTimeout(function () {
    //                    thisdelete.remove();
    //                }, 400);
    //            }
    //        }
    //    }
    //    return false;
    //});

    jQuery(document).on('click', '.confirm-fault-msg-region', function () {
        jQuery(this).slideUp(200);
    });

    //jQuery(document).on('focus', '.txtinput-calendar-date', function () {
    //    jQuery(this).datepicker({});
    //});

    /*jQuery(document).on('focus', '.txtinput-calendar-date', function () {
        jQuery(this).datepicker({
            prevText: '<i class="fa fa-chevron-left"></i>',
            nextText: '<i class="fa fa-chevron-right"></i>',
            showButtonPanel: false
        });
    });

    jQuery(document).on('focus', '.txtinput-calendar-date-change', function () {
        jQuery(this).datepicker({
            prevText: '<i class="fa fa-chevron-left"></i>',
            nextText: '<i class="fa fa-chevron-right"></i>',
            showButtonPanel: false,
            changeMonth: true,
            changeYear: true
        });
    });

    jQuery(document).on('focus', '.txtinput-calendar-time', function () {
        jQuery(this).timepicker({
            showButtonPanel: false,
            beforeShow: function (input, inst) {
                var newclass = 'smart-forms';
                var smartpikr = inst.dpDiv.parent();
                if (!smartpikr.hasClass('smart-forms')) {
                    inst.dpDiv.wrap('<div class="' + newclass + '"></div>');
                }
            }
        });
    });

    jQuery(document).on('focus', '.txtinput-calendar-datetime', function () {
        jQuery(this).datetimepicker({
            showButtonPanel: false,
            prevText: '<i class="fa fa-chevron-left"></i>',
            nextText: '<i class="fa fa-chevron-right"></i>',
            beforeShow: function (input, inst) {
                var newclass = 'smart-forms';
                var smartpikr = inst.dpDiv.parent();
                if (!smartpikr.hasClass('smart-forms')) {
                    inst.dpDiv.wrap('<div class="' + newclass + '"></div>');
                }
                setTimeout(function () {
                    if (jQuery('.ui-datepicker').find('a.ui-state-active').is(':visible')) {
                        jQuery('.ui-datepicker').find('a.ui-state-default').removeClass('ui-state-highlight');
                    }
                }, 50);
            },
            onSelect: function (dateText, inst) {
                setTimeout(function () {
                    jQuery('.ui-datepicker').find('.ui-state-default').removeClass('ui-state-highlight');
                }, 50);
            }
        });
    });

    jQuery(document).on('focus', '.txtinput-calendar-datetime-change', function () {
        jQuery(this).datetimepicker({
            showButtonPanel: false,
            prevText: '<i class="fa fa-chevron-left"></i>',
            nextText: '<i class="fa fa-chevron-right"></i>',
            beforeShow: function (input, inst) {
                var newclass = 'smart-forms';
                var smartpikr = inst.dpDiv.parent();
                if (!smartpikr.hasClass('smart-forms')) {
                    inst.dpDiv.wrap('<div class="' + newclass + '"></div>');
                }
            },
            changeMonth: true,
            changeYear: true,
            onSelect: function (dateText, inst) {
                setTimeout(function () {
                    jQuery('.ui-datepicker').find('.ui-state-default').removeClass('ui-state-highlight');
                }, 50);
            }
        });
    });*/

    jQuery(document).on('focus', '.txtinput-calendar-date', function () {
        jQuery(this).datepicker({
            prevText: '<i class="fa fa-chevron-left"></i>',
            nextText: '<i class="fa fa-chevron-right"></i>',
            showButtonPanel: false,
            dateFormat: 'mm/dd/yy',
            changeMonth: true,
            changeYear: true,
            onSelect: function (dateText, inst) {
                setTimeout(function () {
                    jQuery('.ui-datepicker').find('.ui-state-default').removeClass('ui-state-highlight');
                }, 50);
            },
            beforeShow: function (input, inst) {
                setTimeout(function () {
                    if (jQuery('.ui-datepicker').find('a.ui-state-active').is(':visible')) {
                        jQuery('.ui-datepicker').find('a.ui-state-default').removeClass('ui-state-highlight');
                    }
                }, 50);
            }
        });
    });

    jQuery(document).on('focus', '.txtinput-calendar-date-nochange', function () {
        jQuery(this).datepicker({
            prevText: '<i class="fa fa-chevron-left"></i>',
            nextText: '<i class="fa fa-chevron-right"></i>',
            dateFormat: 'mm/dd/yy',
            showButtonPanel: false,
            onSelect: function (dateText, inst) {
                setTimeout(function () {
                    jQuery('.ui-datepicker').find('.ui-state-default').removeClass('ui-state-highlight');
                }, 50);
            },
            beforeShow: function (input, inst) {
                setTimeout(function () {
                    if (jQuery('.ui-datepicker').find('a.ui-state-active').is(':visible')) {
                        jQuery('.ui-datepicker').find('a.ui-state-default').removeClass('ui-state-highlight');
                    }
                }, 50);
            }
        });
    });

    jQuery(document).on('focus', '.txtinput-calendar-time', function () {
        jQuery(this).timepicker({
            beforeShow: function (input, inst) {
                var newclass = 'smart-forms';
                var smartpikr = inst.dpDiv.parent();
                if (!smartpikr.hasClass('smart-forms')) {
                    inst.dpDiv.wrap('<div class="' + newclass + '"></div>');
                }
            }
        });
    });

    jQuery(document).on('focus', '.txtinput-calendar-datetime', function () {
        jQuery(this).datetimepicker({
            prevText: '<i class="fa fa-chevron-left"></i>',
            nextText: '<i class="fa fa-chevron-right"></i>',
            beforeShow: function (input, inst) {
                var newclass = 'smart-forms';
                var smartpikr = inst.dpDiv.parent();
                if (!smartpikr.hasClass('smart-forms')) {
                    inst.dpDiv.wrap('<div class="' + newclass + '"></div>');
                }
                setTimeout(function () {
                    if (jQuery('.ui-datepicker').find('a.ui-state-active').is(':visible')) {
                        jQuery('.ui-datepicker').find('a.ui-state-default').removeClass('ui-state-highlight');
                    }
                }, 50);
            },
            changeMonth: true,
            changeYear: true,
            onSelect: function (dateText, inst) {
                setTimeout(function () {
                    jQuery('.ui-datepicker').find('.ui-state-default').removeClass('ui-state-highlight');
                }, 50);
            }
        });
    });

    jQuery(document).on('focus', '.txtinput-calendar-datetime-nochange', function () {
        jQuery(this).datetimepicker({
            prevText: '<i class="fa fa-chevron-left"></i>',
            nextText: '<i class="fa fa-chevron-right"></i>',
            dateFormat: 'mm/dd/yy',
            beforeShow: function (input, inst) {
                var newclass = 'smart-forms';
                var smartpikr = inst.dpDiv.parent();
                if (!smartpikr.hasClass('smart-forms')) {
                    inst.dpDiv.wrap('<div class="' + newclass + '"></div>');
                }
                setTimeout(function () {
                    if (jQuery('.ui-datepicker').find('a.ui-state-active').is(':visible')) {
                        jQuery('.ui-datepicker').find('a.ui-state-default').removeClass('ui-state-highlight');
                    }
                }, 50);
            },
            onSelect: function (dateText, inst) {
                setTimeout(function () {
                    jQuery('.ui-datepicker').find('.ui-state-default').removeClass('ui-state-highlight');
                }, 50);
            }

        });
    });

    /*jQuery('.txtinput-calendar-from').datepicker({
        onClose: function (selectedDate) {
            jQuery(this).parent().find(".txtinput-calendar-to").datepicker("option", "minDate", selectedDate);
        }
    });

    jQuery('.txtinput-calendar-to').datepicker({
        onClose: function (selectedDate) {
            jQuery(this).parent().find(".txtinput-calendar-from").datepicker("option", "MaxDate", selectedDate);
        }
    });*/

    /*jQuery(document).on('click', '.ui-datepicker-calendar td', function () {
        //jQuery(this).addClass('ui-state-active');
        //jQuery(this).parent().parent().find('a').removeClass('ui-state-highlight');
    });*/

    jQuery(document).on('focus', '.txtinput-calendar-from', function () {
        jQuery(this).datepicker({
            onClose: function (selectedDate) {
                jQuery(this).parent().find(".txtinput-calendar-to").datepicker("option", "minDate", selectedDate);
            }
            , dateFormat: 'mm/dd/yy'
        });
    });

    jQuery(document).on('focus', '.txtinput-calendar-to', function () {
        jQuery(this).datepicker({
            onClose: function (selectedDate) {
                jQuery(this).parent().find(".txtinput-calendar-from").datepicker("option", "MaxDate", selectedDate);
            }
			, dateFormat: 'mm/dd/yy'
			, minDate: jQuery(this).parent().find(".txtinput-calendar-from").val()
        });
    });

    //jQuery(document).on('click', '.delete-media-file-from-list', function () {
    //    var thisclick = jQuery(this).parent();
    //    thisclick.slideUp(200);
    //    setTimeout(function () {
    //        thisclick.remove();
    //    },400);
    //});

    //jQuery(document).on('click', '.btn-active-all-menu', function () {
    //    jQuery(this).parents().eq(6).find('.content-table-area>ul>li>.content-table-region>ul').each(function () {
    //        //li-table-status
    //        if (jQuery(this).find('.hidden-checkbox-val').val().trim().length > 0)
    //        {
    //            jQuery(this).find('.li-table-status').text('فعال');
    //        }
    //    });
    //    jQuery('.checkbox-checkall').removeClass('checkbox-checked');
    //    jQuery('.checkbox-style').removeClass('checkbox-checked');
    //    jQuery('.hidden-checkbox-val').val('');
    //});
    
    //jQuery(document).on('click', '.btn-inactive-all-menu', function () {
    //    jQuery(this).parents().eq(6).find('.content-table-area>ul>li>.content-table-region>ul').each(function () {
    //        //li-table-status
    //        if (jQuery(this).find('.hidden-checkbox-val').val().trim().length > 0) {
    //            jQuery(this).find('.li-table-status').text('غير فعال');
    //        }
    //    });
    //    jQuery('.checkbox-checkall').removeClass('checkbox-checked');
    //    jQuery('.checkbox-style').removeClass('checkbox-checked');
    //    jQuery('.hidden-checkbox-val').val('');
    //});

    /*jQuery(document).on('click', '.btn-delete-all-menu', function () {
        jQuery(this).parents().eq(6).find('.content-table-area>ul>li>.content-table-region>ul>.first-li-table-check').each(function () {
            if (jQuery(this).find('.hidden-checkbox-val').val().trim().length > 0) {
                if (jQuery(this).parent().parent().hasClass('content-table-region-nested')) {
                    jQuery(this).parent().parent().remove();
                }
                else {
                    jQuery(this).parents().eq(2).remove();
                }
            }
            jQuery('.checkbox-checkall').removeClass('checkbox-checked');
        });
    });*/

    //jQuery(document).on('click', '.btn-table-process', function () {
    //    var data_process = jQuery(this).parent().find('.hidden-application-menu-dropdown').attr('data-process');
    //    var btn_delete_all = jQuery(this).parents().eq(2).find('.btn-delete-all-menu');
    //    var btn_active_all = jQuery(this).parents().eq(2).find('.btn-active-all-menu');
    //    var btn_inactive_all = jQuery(this).parents().eq(2).find('.btn-inactive-all-menu');

    //    if (data_process == "delete")
    //    {
    //        btn_delete_all.parents().eq(6).find('.content-table-area>ul>li>.content-table-region>ul>.first-li-table-check').each(function () {
    //            if (jQuery(this).find('.hidden-checkbox-val').val().trim().length > 0) {
    //                if (jQuery(this).parent().parent().hasClass('content-table-region-nested')) {
    //                    jQuery(this).parent().parent().remove();
    //                }
    //                else {
    //                    jQuery(this).parents().eq(2).remove();
    //                }
    //            }
    //            jQuery('.checkbox-checkall').removeClass('checkbox-checked');
    //        });
    //    }

    //    if (data_process == "active")
    //    {
    //        btn_active_all.parents().eq(6).find('.content-table-area>ul>li>.content-table-region>ul').each(function () {
    //            if (jQuery(this).find('.hidden-checkbox-val').val().trim().length > 0) {
    //                jQuery(this).find('.li-table-status').text('فعال');
    //            }
    //        });
    //    }

    //    if (data_process == "inactive") {
    //        btn_inactive_all.parents().eq(6).find('.content-table-area>ul>li>.content-table-region>ul').each(function () {
    //            if (jQuery(this).find('.hidden-checkbox-val').val().trim().length > 0) {
    //                jQuery(this).find('.li-table-status').text('غير فعال');
    //            }
    //        });
    //    }

    //    jQuery('.checkbox-checkall').removeClass('checkbox-checked');
    //    jQuery('.checkbox-style').removeClass('checkbox-checked');
    //    jQuery('.hidden-checkbox-val').val('');
    //    jQuery('.hidden-application-menu-dropdown').val('');
    //    jQuery(this).parent().find('.application-menu-value').text('اختر');

    //});

    jQuery(document).on('keyup', '#search-txt', function () {
        var txtinput = jQuery(this).val();
        var regexp_open = /\(/;
        var regexp_close = /\)/;
        if (txtinput.search('script') >= 0 || (regexp_open.test(txtinput) == true) || (regexp_close.test(txtinput) == true)) {
            jQuery(this).val('');
        }
        else {
            jQuery('#main-menu>ul>li').each(function () {

                if (jQuery(this).find('a>span').text().search(txtinput) >= 0) {
                    jQuery(this).show();
                }
                else {
                    jQuery(this).hide();
                }
            });
        }
    });

    jQuery(document).on('keyup', 'input[type=text]', function () {
        var txtinput = jQuery(this).val();
        if (txtinput.search('script') >= 0) {
            jQuery(this).val('');
        }
    });
    
    jQuery('.counter-txtarea-chars-input-maxlength').each(function () {
        jQuery(this).text(jQuery(this).parent().parent().find('.counter-txtarea').attr('maxlength'));
    });
    jQuery('.counter-txtarea-chars-number').each(function () {
        jQuery(this).text(jQuery(this).parent().parent().find('.counter-txtarea').val().length);
    });

    jQuery(document).on('keyup', '.counter-txtarea', function () {
        var counter_txtarea_maxlength = jQuery(this).attr('maxlength');
        var counter_txtarea_currentlength = jQuery(this).val().length;

        jQuery(this).parent().find('.counter-txtarea-chars-number').text(jQuery(this).val().length);

        if ((counter_txtarea_maxlength - counter_txtarea_currentlength) <= 5) {
            jQuery(this).parent().find('.counter-txtarea-chars-number').addClass('counter-txtarea-chars-number-error');
        }
        else {
            jQuery(this).parent().find('.counter-txtarea-chars-number').removeClass('counter-txtarea-chars-number-error');
        }
    });

    jQuery(".tab-content-statistics-region").not(":first").hide();
    jQuery(".tab-yearly-monthly-menu-region li:first").find('.tab-yearly-monthly-menu-text').addClass("yearly-monthly-menu-select");
    jQuery(document).on('click', ".tab-yearly-monthly-menu-region li", function () {
        var index = jQuery(this).parent().find('li').index(this);
        if (!jQuery(this).children('.yearly-monthly-menu-text').hasClass("yearly-monthly-menu-select")) {
            jQuery(".tab-content-statistics-region:visible").hide();
            jQuery(".tab-content-statistics-region").eq(index).show();
            jQuery(".tab-yearly-monthly-menu-region>ul>li").find('.tab-yearly-monthly-menu-text').removeClass("yearly-monthly-menu-select");
            jQuery(this).find('.tab-yearly-monthly-menu-text').addClass("yearly-monthly-menu-select");
        }
        return false;
    });

    jQuery(document).click(function () {
        jQuery('.dropdown-chart-area ul').slideUp(100);
        jQuery('.dropdown-chart-region').removeClass('dropdown-chart-region-active');
    });
    
    jQuery(document).on('click', '.dropdown-chart-region', function () {
        jQuery(document).click();
        if (!jQuery(this).parent().find('ul').is(':visible')) {
            jQuery(this).parent().find('ul').css({'display':'block'});
            jQuery(this).addClass('dropdown-chart-region-active');
        }
        else {
            jQuery(this).parent().find('ul').css({'display':'none'});
            jQuery(this).removeClass('dropdown-chart-region-active');
        }
        return false;
    });
    

    jQuery(document).on('click', '.dropdown-chart-area>ul>li>span', function () {
        jQuery(this).parents().eq(2).find('.dropdown-chart-region>span').text(jQuery(this).text());
        jQuery(this).parents().eq(2).find('.hidden-dropdown-chart').val(jQuery(this).text());
    });

    function line_chart_animate() {
        jQuery('.data-one-column-chart-region').height('0');
        jQuery('.data-one-column-chart-region').each(function () {
            var data_height = jQuery(this).attr('data-height');
            jQuery(this).animate({ height: data_height }, 1500);
        });
    }

    line_chart_animate();

    function line_week_small_animate() {

        jQuery('.content-statistics-li-statistics-li-week>ul>li>span').height('0');
        jQuery('.content-statistics-li-statistics-li-week>ul>li>span').each(function () {
            var data_height = jQuery(this).attr('data-height');
            jQuery(this).animate({ height: data_height }, 1500);
        });
    }

    line_week_small_animate();

    jQuery(document).on('click', '.table-more-icon', function () {
        var indexli = jQuery('.content-table-area>ul>li').index(jQuery(this).parents().eq(3));
        var sizeul = parseInt(jQuery('.content-table-area>ul>li').eq(indexli).find('.content-table-region>ul>li').size() - 1);
        var indexlink = jQuery('.content-table-area>ul>li').eq(indexli).find('.content-table-region>ul>li').index(jQuery('.content-table-area>ul>li').eq(indexli).find('.table-link-icon').parent());
        
        var i;
        
        for (i = 1; i < sizeul; i++)
        {
            if (i == indexlink) {
                continue;
            }
            else {
                jQuery('ul.table-more-details').append(
                    '<li>'
                        + '<h2>' + jQuery('.header-table-region>ul>li').eq(i).text() + '</h2>'
                        + '<h3>' + jQuery('.content-table-area>ul>li').eq(indexli).find('.content-table-region>ul>li').eq(i).text() + '</h3>'
                    + '</li>'
                );
            }
        }

        jQuery('.overlay-region').show();
        jQuery('.modal-region').show();

        jQuery('html,body').animate({ scrollTop: 0 }, 0);

        var screenheight = parseInt(jQuery(window).height());
        var modalheight = parseInt(jQuery('.modal-region').height());

        var topspace;
        if (screenheight > modalheight) {
            topspace = (screenheight - modalheight) / 2;
        }
        else {
            topspace = 50;
        }

        jQuery('body').css({ 'min-height': (modalheight + topspace + 20) });

        jQuery('.modal-region').animate({ top: topspace }, 400);

        return false;
    });

    jQuery(document).on('click', '.modal-close', function () {
        var thiclick = jQuery(this);
        thiclick.parent().parent().animate({ top: '-200%' }, 400);
        setTimeout(function () {
            jQuery('.overlay-region').hide();
            thiclick.parent().parent().hide().find('ul.table-more-details').html('');
            jQuery('body').css({ 'min-height': 'auto' });
            //jQuery('.txtinput-normal').removeClass('error-required required-field');
        }, 600);
        popup_region = false;
    });

    var popup_region = false;

    jQuery(document).on('click', '.overlay-region', function () {
        if (popup_region == false) {
            var thiclick = jQuery('.modal-close');
            thiclick.parent().parent().animate({ top: '-200%' }, 400);
            setTimeout(function () {
                jQuery('.overlay-region').hide();
                jQuery('.modal-region').hide().find('ul.table-more-details').html('');
                jQuery('body').css({ 'min-height': 'auto' });
                //jQuery('.txtinput-normal').removeClass('error-required required-field');
            }, 600);
        }
        popup_region = false;
    });

    jQuery(document).on('keyup', function (e) {
        if (e.keyCode == 27) {
            jQuery('.modal-close').click();
        }
    });

    //NProgress.start();
    //setTimeout(function() { NProgress.done(); $('.fade').removeClass('out'); }, 1000); 
    
    jQuery(".dropdown-menu-normal-list").mCustomScrollbar({
        theme:"minimal-dark"
    });

});


