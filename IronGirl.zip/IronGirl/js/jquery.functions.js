$(function() {
    function i(i) {
        i = i || window.event, i.preventDefault && (i.preventDefault(), i.returnValue = !1)
    }

    function e(e) {
        for (var t = keys.length; t--;)
            if (e.keyCode === keys[t]) return void i(e)
    }

    function t(e) {
        i(e)
    }

    function n() {
        window.addEventListener && window.addEventListener("DOMMouseScroll", t, !1), window.onmousewheel = document.onmousewheel = t, document.onkeydown = e
    }

    function a() {
        window.removeEventListener && window.removeEventListener("DOMMouseScroll", t, !1), window.onmousewheel = document.onmousewheel = document.onkeydown = null
    }

    function s(i, e, t) {
        function n() {
            $(e).position().left > r ? $(e).animate({
                left: "-=" + o + "px"
            }, 600, "easeInOutExpo") : $(e).position().left == r && $(e).animate({
                left: 0
            }, 600, "easeInOutBack")
        }

        function a() {
            u && clearInterval(u), u = setInterval(function() {
                n()
            }, 5e3)
        }
        var s = $(t).length,
            o = $(".box_adds").outerWidth(!0),
            d = o * s,
            c = Math.round($(i).width() / o),
            l = c * o,
            r = l - d;
        $(e).css({
            width: d,
            left: 0
        }), a()
    }

    function o() {
        var i = ($(window).width(), $(window).height(), $(".side_menu_set").height()),
            e = $(".side_menu_set a").length,
            t = i / e;
        $(".side_menu_set a").css({
            height: t,
            "line-height": t + "px"
        }), $(".slide").css({
            width: $(".box_adds").width()
        }), s(".ads_slider", ".slides", ".slide")
    }

    function d() {
        $(".has_img").each(function() {
            var i = $(this),
                e = i.find("img"),
                t = e.attr("data-id");
            $('<img src="' + t + '">').load(function() {
                i.css({
                    "background-image": "url(" + t + ")"
                }).animate({
                    opacity: 1
                }), e.removeAttr("data-id").attr({
                    src: t
                })
            })
        }), $(".bimg").each(function() {
            var i = $(this);
            i.closest(".bimg_set").append('<div class="bimg_slide"> <div class="bimg_lt"> <i class="bimg a"></i> <i class="bimg b"></i> </div> <div class="bimg_rt"> <i class="bimg a"></i> <i class="bimg b"></i> </div> </div>');
            var e = i.find("img"),
                t = e.attr("data-id"),
                n = i.closest(".bimg_set").find("i");
            $('<img src="' + t + '">').load(function() {
                n.css({
                    "background-image": "url(" + t + ")"
                }).animate({
                    opacity: 1
                }), e.removeAttr("data-id").attr({
                    src: t
                })
            })
        }), $(".video_set").fitVids()
    }

    function c() {
        $("nav > a, .nav_icon, .sm_set").removeClass("active")
    }
    var u, l, r;
    n();
    var f = function() {
        var i = {};
        return function(e, t, n) {
            n || (n = "Don't call this twice without a uniqueId"), i[n] && clearTimeout(i[n]), i[n] = setTimeout(e, t)
        }
    }();
    s(".ads_slider", ".slides", ".slide"), $.fn.inSlider = function() {
        return this.each(function() {
            var t = $(this);
            //e()
        })
    }, $(".in_slides").inSlider(), o(), $(window).on("resize scroll", function() {
        var i = $(window).scrollTop();
        i > 94 ? $("body").addClass("fixed") : $("body").removeClass("fixed")
    }), $(window).bind("resize", function() {
        f(function() {
            o()
        }, 500)
    }), $(window).on("load", function() {
        $("#loader").fadeOut(function() {
            a(), $(this).remove(), d()
        })
    }), window.onfocus = function() {
        r = !0
    }, window.onblur = function() {
        r = !1
    }, $(".m_arrow").click(function() {
        $(this).next("select").simulate("mousedown")
    }), $(window).bind("beforeunload", function() {
        0 == $(".unload").length && ($("body").append('<div class="unload"></div>'), $("body *").unbind(), $(".unload").fadeIn())
    }),/* $("nav > a").mouseenter(function() {
        var i = $(this),
            e = $(this).attr("data-id"),
            t = $("#" + e);
        $(".sm_set").removeClass("force"), t.length > 0 ? ($("nav > a, .nav_icon").removeClass("active"), i.add(".sm_set").addClass("active"), 
            $(".sm_wrapper").hide(), t.show(), $(".hide").each(function() {
            window.clearTimeout($(this).data("hide"))
        }),
        $(".hide").stop(!0, !0, !0).css({
            opacity: 0
        }),
        t.find(".hide").each(function(i) {
            var e = setTimeout(function() {
                t.find(".hide").eq(i).animate({
                    opacity: 1
                }, 1e3, "easeInOutCubic")
            }, 10 * (i + 1));
            $(this).data("hide", e)
        })) : $("nav > a, .nav_icon, .sm_set").removeClass("active")

    }),*/ $(".nav_icon").click(function() {
        var i = $(this),
            e = $(this).attr("data-id"),
            t = $("#" + e);
        t.length > 0 && !$(this).hasClass("active") ? ($(".nav_icon, nav > a").removeClass("active"), $(".sm_set").addClass("active force"), i.addClass("active"), $(".sm_wrapper").hide(), t.show(), $(".hide").each(function() {
            window.clearTimeout($(this).data("hide"))
        }), $(".hide").stop(!0, !0, !0).css({
            opacity: 0
        }), t.find(".hide").each(function(i) {
            var e = setTimeout(function() {
                t.find(".hide").eq(i).animate({
                    opacity: 1
                }, 1e3, "easeInOutCubic")
            }, 50 * (i + 1));
            $(this).data("hide", e)
        })) : $(".nav_icon, .sm_set").removeClass("active force")
    }), $(document).keyup(function(i) {
        27 == i.keyCode && c()
    }), $(".content").click(function() {
        c()
    }), $(".sm_set").mouseleave(function() {
        $(".nav_icon").hasClass("active") || c()
    }), $(".sm_set").click(function() {
        $(this).find("input").focus()
    }), $(".section.bx_unq .box").mouseenter(function() {
        var i = $(this);
        if (!i.hasClass("wait")) {
            i.addClass("wait");
            var e = i.find(".bimg_rt"),
                t = i.find(".bimg_lt");
            e.transit({
                y: 0
            }, 1e3, "easeOutExpo"), t.transit({
                y: "-50%"
            }, 1e3, "easeOutExpo", function() {
                e.css({
                    y: "-50%"
                }), t.css({
                    y: 0
                }), i.removeClass("wait")
            })
        }
    }), $(".in_action a").click(function() {
        $(".vt_options a").removeClass("selected").addClass("none"), $(this).removeClass("none").addClass("selected")
    }), $(".vt_action a").click(function() {
        $("input:radio[name=option]").is(":checked") && ($(this).hide(), $(".vt_load").fadeIn(function() {
            $("#get_res").load("inc/vote.php", function() {
                function i() {
                    var i = $(".vt_options").find(".chart");
                    i.each(function(e) {
                        var t = $(this).attr("data-title");
                        setTimeout(function() {
                            i.eq(e).stop().animate({
                                width: t + "%"
                            }, 800, "easeInOutCubic")
                        }, 150 * (e + 1))
                    })
                }
                $(".vt_load").delay(1500).fadeOut(function() {
                    i()
                })
            })
        }))
    }), $("#email").focus(function() {
        $(".placeholder").transit({
            y: -5,
            rotateX: "-50deg",
            opacity: 0
        }, 300)
    }).blur(function() {
        var i = $(this).val();
        0 == i.length && $(".placeholder").transit({
            y: 0,
            rotateX: 0,
            opacity: 1
        }, 300)
    }), $(".menu_icon").click(function() {
        {
            var i = $(this),
                e = $(".side_menu_set");
            $(".nav_set")
        }
        $(this).hasClass("active") ? (a(), i.add("body").removeClass("active"), e.stop().delay(500).animate({
            opacity: 0
        }, function() {
            $(this).hide()
        })) : (n(), e.stop().show().animate({
            opacity: 1
        }, function() {
            i.add("body").addClass("active")
        }))
    }), $('a[href="/"]').click(function() {
        return !1
    });

    $("nav > a").mouseenter(function() {
        var i = $(this),
            e = $(this).attr("data-id"),
            t = $("#" + e);

        $(".sm_set").removeClass("force");

        if(t.length > 0)
        {
            $("nav > a, .nav_icon").removeClass("active");
        

            i.add(".sm_set").addClass("active"), 
                $(".sm_wrapper").hide(), t.show(), $(".hide").each(function() {
                window.clearTimeout($(this).data("hide"))
            });

            $(".sm_wrapper:not(#"+e+") .hide").stop(!0, !0, !0).css({
                opacity: 0
            });

            t.find(".hide").each(function(i) {
                var e = setTimeout(function() {
                    t.find(".hide").eq(i).animate({
                        opacity: 1
                    }, 1e3, "easeInOutCubic")
                }, 10 * (i + 1));
                $(this).data("hide", e)
            });
        }
        else
        {
            $("nav > a, .nav_icon, .sm_set").removeClass("active")
        }
    })
});